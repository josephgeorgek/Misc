
@echo off
echo 🚀 Starting Bitbucket CORS Proxy Server...

REM Check if Node.js is installed
node --version >nul 2>&1
if errorlevel 1 (
    echo ❌ Node.js is not installed. Please install Node.js first.
    pause
    exit /b 1
)

REM Check if npm is installed
npm --version >nul 2>&1
if errorlevel 1 (
    echo ❌ npm is not installed. Please install npm first.
    pause
    exit /b 1
)

REM Install dependencies if node_modules doesn't exist
if not exist "node_modules" (
    echo 📦 Installing dependencies...
    npm install express http-proxy-middleware cors
)

REM Start the proxy server
echo 🌐 Starting proxy server on port 3001...
node proxy-server.js

pause
