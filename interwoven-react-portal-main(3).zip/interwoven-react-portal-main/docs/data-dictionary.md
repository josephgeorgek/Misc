
# Data Dictionary & Data Profiling Report

## Database Schema: Regional Bank System

### Table: users

| Column | Data Type | Nullable | Max Length | Primary Key | Foreign Key | Description |
|--------|-----------|----------|------------|-------------|-------------|-------------|
| id | BIGINT | No | N/A | Yes | No | Auto-incrementing primary key for user identification |
| organization_id | VARCHAR(50) | No | 50 | No | No | Organization identifier for corporate users |
| user_id | VARCHAR(50) | No | 50 | No | No | Unique user identifier within organization |
| password | VARCHAR(100) | No | 100 | No | No | Encrypted user password |
| country | VARCHAR(5) | No | 5 | No | No | ISO country code (SG, MY, HK, ID, CN, VN, TH) |
| active | BOOLEAN | No | N/A | No | No | User account active status (default: true) |
| blocked | BOOLEAN | No | N/A | No | No | User account blocked status (default: false) |

#### Data Profile - users table:
- **Total Records**: 14 (test data)
- **Countries Supported**: 7 (SG, MY, HK, ID, CN, VN, TH)
- **Organizations**: 2 unique (ACME001, CORP002)
- **Active Users**: 100% (14/14)
- **Blocked Users**: 0% (0/14)
- **Password Pattern**: All test passwords are plain text (production should be encrypted)

### Table: content_data

| Column | Data Type | Nullable | Max Length | Primary Key | Foreign Key | Description |
|--------|-----------|----------|------------|-------------|-------------|-------------|
| id | BIGINT | No | N/A | Yes | No | Auto-incrementing primary key |
| country | VARCHAR(5) | No | 5 | No | No | ISO country code for content localization |
| language | VARCHAR(5) | No | 5 | No | No | Language code (en, zh) |
| content_type | VARCHAR(20) | No | 20 | No | No | Type of content (banner, background, announcement) |
| content_data | TEXT | Yes | 65535 | No | No | JSON or text content data |
| background_url | VARCHAR(500) | Yes | 500 | No | No | URL path to background images |

#### Data Profile - content_data table:
- **Total Records**: 33 (estimated from schema)
- **Content Types**: 3 (banner, background, announcement)
- **Languages Supported**: 2 (en, zh)
- **Countries with Content**: 7 (all supported regions)
- **Background URLs**: Mix of local paths and external URLs
- **Content Format**: JSON for banners, plain text for announcements

## Data Quality Issues Identified:

### Critical Issues:
1. **Password Security**: Test passwords are stored in plain text
2. **Data Consistency**: Some content entries may have null content_data
3. **URL Validation**: No validation for background_url format

### Moderate Issues:
1. **Referential Integrity**: No foreign key constraints between tables
2. **Data Redundancy**: Content duplicated across countries/languages
3. **Character Encoding**: No explicit UTF-8 specification for multilingual content

### Recommendations:
1. Implement password hashing (BCrypt/Argon2)
2. Add foreign key constraints
3. Implement data validation rules
4. Add indexes for performance optimization
5. Consider content versioning system
