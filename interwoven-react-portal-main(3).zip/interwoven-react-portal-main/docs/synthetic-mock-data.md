
# Synthetic/Mock Data Generation Guide

## Overview

This document provides comprehensive mock data sets and generation strategies for testing the Regional Banking Application across different environments and scenarios.

## User Account Mock Data

### Test Users by Country

```json
{
  "singapore": [
    {
      "organizationId": "ACME001",
      "userId": "SARAH01",
      "password": "SecurePass123!",
      "userType": "corporate_finance_manager",
      "active": true,
      "blocked": false,
      "lastLogin": "2024-12-24T08:30:00Z",
      "loginCount": 245,
      "preferredLanguage": "en",
      "mfaEnabled": true
    },
    {
      "organizationId": "TECH999",
      "userId": "DAVID02",
      "password": "TechPass456#",
      "userType": "it_administrator",
      "active": true,
      "blocked": false,
      "lastLogin": "2024-12-24T07:15:00Z",
      "loginCount": 89,
      "preferredLanguage": "en",
      "mfaEnabled": true
    }
  ],
  "malaysia": [
    {
      "organizationId": "LOGIS001",
      "userId": "AHMAD1",
      "password": "LogisPass789@",
      "userType": "sme_business_owner",
      "active": true,
      "blocked": false,
      "lastLogin": "2024-12-24T09:00:00Z",
      "loginCount": 156,
      "preferredLanguage": "en",
      "mfaEnabled": false
    },
    {
      "organizationId": "TRADE002",
      "userId": "FATIMA",
      "password": "TradePass321$",
      "userType": "finance_specialist",
      "active": true,
      "blocked": false,
      "lastLogin": "2024-12-23T16:45:00Z",
      "loginCount": 203,
      "preferredLanguage": "ms",
      "mfaEnabled": true
    }
  ],
  "hongkong": [
    {
      "organizationId": "MULTI001",
      "userId": "LIWEI3",
      "password": "TreasuryPass567%",
      "userType": "corporate_treasurer",
      "active": true,
      "blocked": false,
      "lastLogin": "2024-12-24T06:30:00Z",
      "loginCount": 312,
      "preferredLanguage": "zh",
      "mfaEnabled": true
    }
  ]
}
```

### Blocked/Inactive Test Users

```json
{
  "blocked_users": [
    {
      "organizationId": "FRAUD001",
      "userId": "BLOCK1",
      "password": "BlockedPass123!",
      "active": false,
      "blocked": true,
      "blockReason": "Multiple failed login attempts",
      "blockDate": "2024-12-20T14:30:00Z"
    },
    {
      "organizationId": "SUSPENDED",
      "userId": "SUSP01",
      "password": "SuspendPass456@",
      "active": false,
      "blocked": true,
      "blockReason": "Account under investigation",
      "blockDate": "2024-12-15T10:00:00Z"
    }
  ]
}
```

## Transaction Mock Data

### High-Volume Transaction Sets

```json
{
  "bulk_transactions": [
    {
      "transactionId": "TXN-SG-20241224-001",
      "organizationId": "ACME001",
      "userId": "SARAH01",
      "country": "sg",
      "amount": 150000.50,
      "currency": "SGD",
      "transactionType": "vendor_payment",
      "status": "completed",
      "timestamp": "2024-12-24T10:15:00Z",
      "beneficiary": "SUPPLIER-TECH-001",
      "reference": "INV-2024-12345"
    },
    {
      "transactionId": "TXN-MY-20241224-002",
      "organizationId": "LOGIS001",
      "userId": "AHMAD1",
      "country": "my",
      "amount": 75000.00,
      "currency": "MYR",
      "transactionType": "payroll",
      "status": "pending",
      "timestamp": "2024-12-24T10:30:00Z",
      "beneficiary": "EMPLOYEE-BATCH-001",
      "reference": "PAY-2024-DEC"
    }
  ]
}
```

### Load Testing Transaction Patterns

```javascript
// Generate large transaction datasets
function generateTransactionLoad(count, country) {
  const transactions = [];
  const baseDate = new Date('2024-12-01');
  
  for (let i = 0; i < count; i++) {
    transactions.push({
      transactionId: `TXN-${country.toUpperCase()}-${Date.now()}-${i}`,
      organizationId: `ORG${String(Math.floor(Math.random() * 1000)).padStart(3, '0')}`,
      userId: `USER${String(i).padStart(6, '0')}`,
      country: country,
      amount: Math.random() * 1000000,
      currency: getCurrencyForCountry(country),
      transactionType: getRandomTransactionType(),
      status: getRandomStatus(),
      timestamp: new Date(baseDate.getTime() + (Math.random() * 24 * 24 * 60 * 60 * 1000)).toISOString()
    });
  }
  return transactions;
}

function getCurrencyForCountry(country) {
  const currencies = {
    'sg': 'SGD', 'my': 'MYR', 'hk': 'HKD',
    'id': 'IDR', 'cn': 'CNY', 'vn': 'VND', 'th': 'THB'
  };
  return currencies[country] || 'USD';
}
```

## Content Mock Data

### Banner Content by Region/Language

```json
{
  "banner_content": {
    "sg": {
      "en": {
        "title": "Welcome to Business Banking Singapore",
        "subtitle": "Secure and efficient banking for your business needs",
        "backgroundUrl": "/images/sg-business-banner.jpg",
        "ctaText": "Get Started",
        "ctaUrl": "/sg/business/onboarding"
      },
      "zh": {
        "title": "欢迎使用新加坡商业银行",
        "subtitle": "为您的企业需求提供安全高效的银行服务",
        "backgroundUrl": "/images/sg-business-banner-zh.jpg",
        "ctaText": "开始使用",
        "ctaUrl": "/sg/business/onboarding"
      }
    },
    "my": {
      "en": {
        "title": "Malaysia Business Banking Solutions",
        "subtitle": "Empowering Malaysian businesses with digital banking",
        "backgroundUrl": "/images/my-business-banner.jpg",
        "ctaText": "Learn More",
        "ctaUrl": "/my/business/solutions"
      }
    }
  }
}
```

### Announcement Content

```json
{
  "announcements": {
    "security_alerts": [
      {
        "id": "SEC-001",
        "country": "all",
        "priority": "high",
        "title": "Enhanced Security Measures",
        "content": "We have implemented additional security measures to protect your account. Please ensure your contact information is up to date.",
        "validFrom": "2024-12-01T00:00:00Z",
        "validTo": "2024-12-31T23:59:59Z",
        "languages": ["en", "zh", "ms", "th", "vi", "id"]
      }
    ],
    "system_maintenance": [
      {
        "id": "MAINT-001",
        "country": "sg",
        "priority": "medium",
        "title": "Scheduled Maintenance",
        "content": "System maintenance will be performed on Dec 25, 2024 from 2:00 AM to 4:00 AM SGT. Services may be temporarily unavailable.",
        "validFrom": "2024-12-24T00:00:00Z",
        "validTo": "2024-12-25T12:00:00Z",
        "languages": ["en", "zh"]
      }
    ]
  }
}
```

## Performance Testing Data Sets

### Concurrent User Simulation

```javascript
// JMeter Thread Group Configuration Data
const loadTestProfiles = {
  "light_load": {
    "concurrent_users": 10,
    "ramp_up_time": 60,
    "test_duration": 300,
    "target_countries": ["sg", "my"]
  },
  "medium_load": {
    "concurrent_users": 50,
    "ramp_up_time": 120,
    "test_duration": 600,
    "target_countries": ["sg", "my", "hk", "id"]
  },
  "heavy_load": {
    "concurrent_users": 200,
    "ramp_up_time": 300,
    "test_duration": 1800,
    "target_countries": ["sg", "my", "hk", "id", "cn", "vn", "th"]
  },
  "stress_test": {
    "concurrent_users": 500,
    "ramp_up_time": 600,
    "test_duration": 3600,
    "target_countries": ["sg", "my", "hk", "id", "cn", "vn", "th"]
  }
};
```

### API Response Time Benchmarks

```json
{
  "performance_benchmarks": {
    "login_api": {
      "target_response_time": "< 2 seconds",
      "acceptable_response_time": "< 5 seconds",
      "success_rate": "> 99%"
    },
    "content_api": {
      "target_response_time": "< 1 second",
      "acceptable_response_time": "< 3 seconds",
      "success_rate": "> 99.5%"
    },
    "transaction_api": {
      "target_response_time": "< 3 seconds",
      "acceptable_response_time": "< 8 seconds",
      "success_rate": "> 99.9%"
    }
  }
}
```

## Error Scenario Mock Data

### Authentication Error Cases

```json
{
  "error_scenarios": {
    "invalid_credentials": [
      {
        "organizationId": "ACME001",
        "userId": "WRONGUSER",
        "password": "wrongpass",
        "expectedError": "AUTH-001",
        "expectedMessage": "Invalid credentials"
      }
    ],
    "blocked_accounts": [
      {
        "organizationId": "BLOCKED001",
        "userId": "BLOCKED",
        "password": "anypass",
        "expectedError": "AUTH-002",
        "expectedMessage": "Account blocked"
      }
    ],
    "system_errors": [
      {
        "organizationId": "ERROR001",
        "userId": "SYSTEM",
        "password": "errorpass",
        "expectedError": "SYSTEM-001",
        "expectedMessage": "Internal server error"
      }
    ]
  }
}
```

## Database Seeding Scripts

### SQL Data Generation

```sql
-- Generate 1000 test users across all countries
INSERT INTO users (organization_id, user_id, password, country, active, blocked)
SELECT 
  CONCAT('ORG', LPAD(FLOOR(RAND() * 1000), 3, '0')) as organization_id,
  CONCAT('USER', LPAD(n, 6, '0')) as user_id,
  CONCAT('TestPass', n, '!') as password,
  CASE FLOOR(RAND() * 7)
    WHEN 0 THEN 'SG'
    WHEN 1 THEN 'MY'
    WHEN 2 THEN 'HK'
    WHEN 3 THEN 'ID'
    WHEN 4 THEN 'CN'
    WHEN 5 THEN 'VN'
    WHEN 6 THEN 'TH'
  END as country,
  RAND() > 0.1 as active,
  RAND() < 0.05 as blocked
FROM (
  SELECT @row := @row + 1 as n
  FROM (SELECT 0 UNION ALL SELECT 1 UNION ALL SELECT 2 UNION ALL SELECT 3) t1,
       (SELECT 0 UNION ALL SELECT 1 UNION ALL SELECT 2 UNION ALL SELECT 3) t2,
       (SELECT 0 UNION ALL SELECT 1 UNION ALL SELECT 2 UNION ALL SELECT 3) t3,
       (SELECT 0 UNION ALL SELECT 1 UNION ALL SELECT 2 UNION ALL SELECT 3) t4,
       (SELECT @row := 0) r
  LIMIT 1000
) numbers;

-- Generate content data for all countries and languages
INSERT INTO content_data (country, language, content_type, content_data, background_url)
SELECT 
  country,
  language,
  content_type,
  CASE content_type
    WHEN 'banner' THEN JSON_OBJECT(
      'title', CONCAT('Welcome to Business Banking ', country),
      'subtitle', 'Secure and reliable banking services',
      'ctaText', 'Get Started'
    )
    WHEN 'announcement' THEN 'Important: System maintenance scheduled for this weekend.'
    ELSE 'Default content'
  END as content_data,
  CASE content_type
    WHEN 'background' THEN CONCAT('/images/', LOWER(country), '-background.jpg')
    ELSE NULL
  END as background_url
FROM (
  SELECT 'SG' as country UNION ALL SELECT 'MY' UNION ALL SELECT 'HK' 
  UNION ALL SELECT 'ID' UNION ALL SELECT 'CN' UNION ALL SELECT 'VN' UNION ALL SELECT 'TH'
) countries
CROSS JOIN (
  SELECT 'en' as language UNION ALL SELECT 'zh'
) languages
CROSS JOIN (
  SELECT 'banner' as content_type UNION ALL SELECT 'background' UNION ALL SELECT 'announcement'
) content_types;
```

## Mock API Response Templates

### Success Response Templates

```json
{
  "login_success": {
    "success": true,
    "message": "Login successful",
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "country": "{{country}}",
    "organizationId": "{{organizationId}}",
    "userId": "{{userId}}",
    "sessionTimeout": 3600
  },
  "content_success": {
    "title": "{{title}}",
    "subtitle": "{{subtitle}}",
    "backgroundUrl": "{{backgroundUrl}}",
    "content": "{{content}}",
    "lastUpdated": "{{timestamp}}"
  }
}
```

### Error Response Templates

```json
{
  "auth_error": {
    "success": false,
    "errorCode": "{{errorCode}}",
    "message": "{{errorMessage}}",
    "timestamp": "{{timestamp}}",
    "requestId": "{{requestId}}"
  },
  "system_error": {
    "errorCode": "SYSTEM-001",
    "message": "Internal server error",
    "details": "Please try again later or contact support",
    "timestamp": "{{timestamp}}",
    "requestId": "{{requestId}}"
  }
}
```

## Data Generation Tools

### Node.js Mock Data Generator

```javascript
const fs = require('fs');
const { faker } = require('@faker-js/faker');

class MockDataGenerator {
  generateUsers(count, country) {
    const users = [];
    for (let i = 0; i < count; i++) {
      users.push({
        organizationId: faker.company.name().toUpperCase().substring(0, 8),
        userId: faker.internet.userName().toUpperCase(),
        password: faker.internet.password(12, false, /[A-Za-z0-9!@#$%]/),
        country: country,
        active: faker.datatype.boolean(0.9),
        blocked: faker.datatype.boolean(0.05),
        createdAt: faker.date.past(2).toISOString(),
        lastLogin: faker.date.recent(30).toISOString()
      });
    }
    return users;
  }

  generateTransactions(count, userId, organizationId, country) {
    const transactions = [];
    for (let i = 0; i < count; i++) {
      transactions.push({
        transactionId: faker.string.uuid(),
        organizationId: organizationId,
        userId: userId,
        country: country,
        amount: faker.finance.amount(100, 1000000, 2),
        currency: this.getCurrencyForCountry(country),
        transactionType: faker.helpers.arrayElement([
          'vendor_payment', 'payroll', 'transfer', 'deposit'
        ]),
        status: faker.helpers.arrayElement([
          'completed', 'pending', 'failed'
        ]),
        timestamp: faker.date.recent(90).toISOString(),
        beneficiary: faker.company.name(),
        reference: faker.finance.transactionDescription()
      });
    }
    return transactions;
  }

  getCurrencyForCountry(country) {
    const currencies = {
      'sg': 'SGD', 'my': 'MYR', 'hk': 'HKD',
      'id': 'IDR', 'cn': 'CNY', 'vn': 'VND', 'th': 'THB'
    };
    return currencies[country] || 'USD';
  }

  exportToFile(data, filename) {
    fs.writeFileSync(filename, JSON.stringify(data, null, 2));
    console.log(`Mock data exported to ${filename}`);
  }
}

// Usage example
const generator = new MockDataGenerator();
const countries = ['sg', 'my', 'hk', 'id', 'cn', 'vn', 'th'];

countries.forEach(country => {
  const users = generator.generateUsers(100, country);
  generator.exportToFile(users, `mock-users-${country}.json`);
});
```

## Usage Guidelines

### For Development Testing
1. Use smaller datasets (10-50 records) for development
2. Include edge cases (blocked users, failed transactions)
3. Test all country/language combinations

### For Performance Testing
1. Use large datasets (1000+ records) for load testing
2. Simulate realistic transaction volumes
3. Test concurrent user scenarios

### For Security Testing
1. Include invalid credential combinations
2. Test blocked/suspended account scenarios
3. Simulate brute force attack patterns

### For Integration Testing
1. Use consistent test data across environments
2. Include cross-country transaction scenarios
3. Test all API endpoint combinations

## Data Refresh Strategy

### Daily Refresh
- Reset user login counts
- Clear transaction logs older than 90 days
- Update content timestamps

### Weekly Refresh
- Regenerate blocked user lists
- Update announcement content
- Refresh performance benchmarks

### Monthly Refresh
- Complete database reset with fresh mock data
- Update user personas based on usage patterns
- Refresh security scenarios

