
# JMeter Performance Testing Scripts

## Overview

This document provides comprehensive JMeter test plans for performance testing the Regional Banking Application APIs across different load scenarios and geographic regions.

## Test Plan Structure

### 1. Master Test Plan Configuration

```xml
<?xml version="1.0" encoding="UTF-8"?>
<jmeterTestPlan version="1.2" properties="5.0" jmeter="5.6.2">
  <hashTree>
    <TestPlan guiclass="TestPlanGui" testclass="TestPlan" testname="Regional Bank API Performance Test">
      <stringProp name="TestPlan.comments">Comprehensive performance testing for Regional Banking APIs</stringProp>
      <boolProp name="TestPlan.functional_mode">false</boolProp>
      <boolProp name="TestPlan.tearDown_on_shutdown">true</boolProp>
      <boolProp name="TestPlan.serialize_threadgroups">false</boolProp>
      <elementProp name="TestPlan.arguments" elementType="Arguments" guiclass="ArgumentsPanel" testclass="Arguments" testname="User Defined Variables">
        <collectionProp name="Arguments.arguments">
          <elementProp name="base_url" elementType="Argument">
            <stringProp name="Argument.name">base_url</stringProp>
            <stringProp name="Argument.value">http://localhost:8080</stringProp>
          </elementProp>
          <elementProp name="test_duration" elementType="Argument">
            <stringProp name="Argument.name">test_duration</stringProp>
            <stringProp name="Argument.value">300</stringProp>
          </elementProp>
          <elementProp name="ramp_up_time" elementType="Argument">
            <stringProp name="Argument.name">ramp_up_time</stringProp>
            <stringProp name="Argument.value">60</stringProp>
          </elementProp>
        </collectionProp>
      </elementProp>
    </TestPlan>
  </hashTree>
</jmeterTestPlan>
```

### 2. Thread Group Configurations

#### Light Load Test (10 Concurrent Users)

```xml
<ThreadGroup guiclass="ThreadGroupGui" testclass="ThreadGroup" testname="Light Load - 10 Users">
  <stringProp name="ThreadGroup.on_sample_error">continue</stringProp>
  <elementProp name="ThreadGroup.main_controller" elementType="LoopController" guiclass="LoopControlGui" testclass="LoopController" testname="Loop Controller">
    <boolProp name="LoopController.continue_forever">false</boolProp>
    <intProp name="LoopController.loops">-1</intProp>
  </elementProp>
  <stringProp name="ThreadGroup.num_threads">10</stringProp>
  <stringProp name="ThreadGroup.ramp_time">60</stringProp>
  <boolProp name="ThreadGroup.scheduler">true</boolProp>
  <stringProp name="ThreadGroup.duration">300</stringProp>
  <stringProp name="ThreadGroup.delay">0</stringProp>
</ThreadGroup>
```

#### Heavy Load Test (200 Concurrent Users)

```xml
<ThreadGroup guiclass="ThreadGroupGui" testclass="ThreadGroup" testname="Heavy Load - 200 Users">
  <stringProp name="ThreadGroup.on_sample_error">continue</stringProp>
  <elementProp name="ThreadGroup.main_controller" elementType="LoopController" guiclass="LoopControlGui" testclass="LoopController" testname="Loop Controller">
    <boolProp name="LoopController.continue_forever">false</boolProp>
    <intProp name="LoopController.loops">-1</intProp>
  </elementProp>
  <stringProp name="ThreadGroup.num_threads">200</stringProp>
  <stringProp name="ThreadGroup.ramp_time">300</stringProp>
  <boolProp name="ThreadGroup.scheduler">true</boolProp>
  <stringProp name="ThreadGroup.duration">1800</stringProp>
  <stringProp name="ThreadGroup.delay">0</stringProp>
</ThreadGroup>
```

#### Stress Test (500 Concurrent Users)

```xml
<ThreadGroup guiclass="ThreadGroupGui" testclass="ThreadGroup" testname="Stress Test - 500 Users">
  <stringProp name="ThreadGroup.on_sample_error">continue</stringProp>
  <elementProp name="ThreadGroup.main_controller" elementType="LoopController" guiclass="LoopControlGui" testclass="LoopController" testname="Loop Controller">
    <boolProp name="LoopController.continue_forever">false</boolProp>
    <intProp name="LoopController.loops">-1</intProp>
  </elementProp>
  <stringProp name="ThreadGroup.num_threads">500</stringProp>
  <stringProp name="ThreadGroup.ramp_time">600</stringProp>
  <boolProp name="ThreadGroup.scheduler">true</boolProp>
  <stringProp name="ThreadGroup.duration">3600</stringProp>
  <stringProp name="ThreadGroup.delay">0</stringProp>
</ThreadGroup>
```

### 3. HTTP Request Samplers

#### Login API Test

```xml
<HTTPSamplerProxy guiclass="HttpTestSampleGui" testclass="HTTPSamplerProxy" testname="Login API - ${country}">
  <elementProp name="HTTPsampler.Arguments" elementType="Arguments" guiclass="HTTPArgumentsPanel" testclass="Arguments" testname="User Defined Variables">
    <collectionProp name="Arguments.arguments"/>
  </elementProp>
  <stringProp name="HTTPSampler.domain">${base_url}</stringProp>
  <stringProp name="HTTPSampler.port">8080</stringProp>
  <stringProp name="HTTPSampler.protocol">http</stringProp>
  <stringProp name="HTTPSampler.contentEncoding"></stringProp>
  <stringProp name="HTTPSampler.path">/${country}/customer-security-corp/v1/orguserid-login</stringProp>
  <stringProp name="HTTPSampler.method">POST</stringProp>
  <boolProp name="HTTPSampler.follow_redirects">true</boolProp>
  <boolProp name="HTTPSampler.auto_redirects">false</boolProp>
  <boolProp name="HTTPSampler.use_keepalive">true</boolProp>
  <boolProp name="HTTPSampler.DO_MULTIPART_POST">false</boolProp>
  <stringProp name="HTTPSampler.embedded_url_re"></stringProp>
  <stringProp name="HTTPSampler.connect_timeout"></stringProp>
  <stringProp name="HTTPSampler.response_timeout"></stringProp>
</HTTPSamplerProxy>
```

#### Login Request Body

```xml
<elementProp name="HTTPsampler.Arguments" elementType="Arguments">
  <collectionProp name="Arguments.arguments">
    <elementProp name="" elementType="HTTPArgument">
      <boolProp name="HTTPArgument.always_encode">false</boolProp>
      <stringProp name="Argument.value">{
  "organisationId": "${organizationId}",
  "userId": "${userId}",
  "password": "${password}"
}</stringProp>
      <stringProp name="Argument.metadata">=</stringProp>
    </elementProp>
  </collectionProp>
</elementProp>
<stringProp name="HTTPSampler.implementation">HttpClient4</stringProp>
<stringProp name="HTTPSampler.postBodyRaw">true</stringProp>
```

#### Content API Tests

```xml
<!-- Banner Content Test -->
<HTTPSamplerProxy guiclass="HttpTestSampleGui" testclass="HTTPSamplerProxy" testname="Get Banner Content - ${country}/${language}">
  <stringProp name="HTTPSampler.domain">${base_url}</stringProp>
  <stringProp name="HTTPSampler.port">8080</stringProp>
  <stringProp name="HTTPSampler.path">/digital-content/${country}/business/web/${language}/bfo/common/banner/banner_content.json</stringProp>
  <stringProp name="HTTPSampler.method">GET</stringProp>
  <boolProp name="HTTPSampler.follow_redirects">true</boolProp>
  <boolProp name="HTTPSampler.use_keepalive">true</boolProp>
</HTTPSamplerProxy>

<!-- Background Image Test -->
<HTTPSamplerProxy guiclass="HttpTestSampleGui" testclass="HTTPSamplerProxy" testname="Get Background Image - ${country}/${language}">
  <stringProp name="HTTPSampler.domain">${base_url}</stringProp>
  <stringProp name="HTTPSampler.port">8080</stringProp>
  <stringProp name="HTTPSampler.path">/digital-content/${country}/business/web/${language}/bfo/common/images/background_image.json</stringProp>
  <stringProp name="HTTPSampler.method">GET</stringProp>
  <boolProp name="HTTPSampler.follow_redirects">true</boolProp>
  <boolProp name="HTTPSampler.use_keepalive">true</boolProp>
</HTTPSamplerProxy>

<!-- Announcement Content Test -->
<HTTPSamplerProxy guiclass="HttpTestSampleGui" testclass="HTTPSamplerProxy" testname="Get Announcement - ${country}/${language}">
  <stringProp name="HTTPSampler.domain">${base_url}</stringProp>
  <stringProp name="HTTPSampler.port">8080</stringProp>
  <stringProp name="HTTPSampler.path">/digital-content/${country}/business/web/${language}/bfo/prelogin/announcement/microsites/microsite_announcement.html</stringProp>
  <stringProp name="HTTPSampler.method">GET</stringProp>
  <boolProp name="HTTPSampler.follow_redirects">true</boolProp>
  <boolProp name="HTTPSampler.use_keepalive">true</boolProp>
</HTTPSamplerProxy>
```

### 4. CSV Data Configuration

#### User Credentials CSV Setup

```xml
<CSVDataSet guiclass="TestBeanGUI" testclass="CSVDataSet" testname="User Credentials Data">
  <stringProp name="filename">${__P(user.dir)}/test-data/user-credentials.csv</stringProp>
  <stringProp name="fileEncoding">UTF-8</stringProp>
  <stringProp name="variableNames">organizationId,userId,password,country</stringProp>
  <boolProp name="ignoreFirstLine">true</boolProp>
  <stringProp name="delimiter">,</stringProp>
  <boolProp name="quotedData">false</boolProp>
  <boolProp name="recycle">true</boolProp>
  <boolProp name="stopThread">false</boolProp>
  <stringProp name="shareMode">shareMode.all</stringProp>
</CSVDataSet>
```

#### Test Data Files

**user-credentials.csv:**
```csv
organizationId,userId,password,country
ACME001,JOHNDOE,password123,sg
ACME001,JANESMITH,password456,sg
LOGIS001,AHMAD1,LogisPass789,my
TRADE002,FATIMA,TradePass321,my
MULTI001,LIWEI3,TreasuryPass567,hk
CORP002,CHAN,password456,hk
ACME001,BUDI,password123,id
CORP002,SARI,password456,id
ACME001,ZHANG,password123,cn
CORP002,LI,password456,cn
ACME001,NGUYEN,password123,vn
CORP002,TRAN,password456,vn
ACME001,SOMCHAI,password123,th
CORP002,MALEE,password456,th
```

**country-language.csv:**
```csv
country,language
sg,en
sg,zh
my,en
hk,en
hk,zh
id,en
cn,zh
vn,en
th,en
```

### 5. Response Assertions

#### Login Success Assertion

```xml
<ResponseAssertion guiclass="AssertionGui" testclass="ResponseAssertion" testname="Login Success Response">
  <collectionProp name="Asserion.test_strings">
    <stringProp name="49586">200</stringProp>
  </collectionProp>
  <stringProp name="Assertion.custom_message"></stringProp>
  <stringProp name="Assertion.test_field">Assertion.response_code</stringProp>
  <boolProp name="Assertion.assume_success">false</boolProp>
  <intProp name="Assertion.test_type">1</intProp>
</ResponseAssertion>

<JSONPostProcessor guiclass="JSONPostProcessorGui" testclass="JSONPostProcessor" testname="Extract Login Token">
  <stringProp name="JSONPostProcessor.referenceNames">auth_token</stringProp>
  <stringProp name="JSONPostProcessor.jsonPathExpressions">$.token</stringProp>
  <stringProp name="JSONPostProcessor.match_numbers">1</stringProp>
</JSONPostProcessor>
```

#### Content Response Assertion

```xml
<ResponseAssertion guiclass="AssertionGui" testclass="ResponseAssertion" testname="Content Response Assertion">
  <collectionProp name="Asserion.test_strings">
    <stringProp name="49586">200</stringProp>
  </collectionProp>
  <stringProp name="Assertion.test_field">Assertion.response_code</stringProp>
  <boolProp name="Assertion.assume_success">false</boolProp>
  <intProp name="Assertion.test_type">1</intProp>
</ResponseAssertion>

<JSONPathAssertion guiclass="JSONPathAssertionGui" testclass="JSONPathAssertion" testname="JSON Path Assertion">
  <stringProp name="JSON_PATH">$.title</stringProp>
  <stringProp name="EXPECTED_VALUE"></stringProp>
  <boolProp name="JSONVALIDATION">true</boolProp>
  <boolProp name="EXPECT_NULL">false</boolProp>
  <boolProp name="INVERT">false</boolProp>
  <boolProp name="ISREGEX">false</boolProp>
</JSONPathAssertion>
```

### 6. Timers and Think Time

#### Gaussian Random Timer

```xml
<GaussianRandomTimer guiclass="GaussianRandomTimerGui" testclass="GaussianRandomTimer" testname="User Think Time">
  <stringProp name="ConstantTimer.delay">2000</stringProp>
  <stringProp name="RandomTimer.range">1000.0</stringProp>
</GaussianRandomTimer>
```

#### Constant Throughput Timer

```xml
<ConstantThroughputTimer guiclass="TestBeanGUI" testclass="ConstantThroughputTimer" testname="Throughput Control">
  <intProp name="calcMode">0</intProp>
  <doubleProp>
    <name>throughput</name>
    <value>60.0</value>
    <savedValue>0.0</savedValue>
  </doubleProp>
</ConstantThroughputTimer>
```

### 7. Listeners and Reporting

#### Aggregate Report Configuration

```xml
<ResultCollector guiclass="StatVisualizer" testclass="ResultCollector" testname="Aggregate Report">
  <boolProp name="ResultCollector.error_logging">false</boolProp>
  <objProp>
    <name>saveConfig</name>
    <value class="SampleSaveConfiguration">
      <time>true</time>
      <latency>true</latency>
      <timestamp>true</timestamp>
      <success>true</success>
      <label>true</label>
      <code>true</code>
      <message>true</message>
      <threadName>true</threadName>
      <dataType>true</dataType>
      <encoding>false</encoding>
      <assertions>true</assertions>
      <subresults>true</subresults>
      <responseData>false</responseData>
      <samplerData>false</samplerData>
      <xml>false</xml>
      <fieldNames>true</fieldNames>
      <responseHeaders>false</responseHeaders>
      <requestHeaders>false</requestHeaders>
      <responseDataOnError>false</responseDataOnError>
      <saveAssertionResultsFailureMessage>true</saveAssertionResultsFailureMessage>
      <assertionsResultsToSave>0</assertionsResultsToSave>
      <bytes>true</bytes>
      <sentBytes>true</sentBytes>
      <url>true</url>
      <threadCounts>true</threadCounts>
      <idleTime>true</idleTime>
      <connectTime>true</connectTime>
    </value>
  </objProp>
  <stringProp name="filename">results/aggregate-report-${__time(yyyyMMdd-HHmmss)}.jtl</stringProp>
</ResultCollector>
```

#### Response Time Graph

```xml
<ResultCollector guiclass="ResponseTimesOverTimeGui" testclass="ResultCollector" testname="Response Times Over Time">
  <boolProp name="ResultCollector.error_logging">false</boolProp>
  <objProp>
    <name>saveConfig</name>
    <value class="SampleSaveConfiguration">
      <time>true</time>
      <latency>true</latency>
      <timestamp>true</timestamp>
      <success>true</success>
      <label>true</label>
      <code>true</code>
      <message>false</message>
      <threadName>true</threadName>
      <dataType>false</dataType>
      <encoding>false</encoding>
      <assertions>false</assertions>
      <subresults>false</subresults>
      <responseData>false</responseData>
      <samplerData>false</samplerData>
      <xml>false</xml>
      <fieldNames>false</fieldNames>
      <responseHeaders>false</responseHeaders>
      <requestHeaders>false</requestHeaders>
      <responseDataOnError>false</responseDataOnError>
      <saveAssertionResultsFailureMessage>false</saveAssertionResultsFailureMessage>
      <assertionsResultsToSave>0</assertionsResultsToSave>
      <bytes>true</bytes>
      <url>true</url>
      <filename>results/response-times-${__time(yyyyMMdd-HHmmss)}.jtl</filename>
    </value>
  </objProp>
</ResultCollector>
```

## Test Scenarios

### Scenario 1: Login Performance Test

**Objective**: Test authentication API performance under various loads

**Steps**:
1. Load user credentials from CSV
2. Send login requests for different countries
3. Validate response time < 2 seconds
4. Check success rate > 99%

**Expected Results**:
- Average response time: < 1.5 seconds
- 95th percentile: < 2.0 seconds
- 99th percentile: < 3.0 seconds
- Error rate: < 1%

### Scenario 2: Content Loading Performance

**Objective**: Test content API performance for banner, background, and announcements

**Steps**:
1. Load country/language combinations
2. Request all content types simultaneously
3. Validate JSON response structure
4. Check response time < 1 second

**Expected Results**:
- Average response time: < 0.8 seconds
- 95th percentile: < 1.2 seconds
- Error rate: < 0.5%

### Scenario 3: Mixed Workload Test

**Objective**: Simulate realistic user behavior with mixed API calls

**Steps**:
1. 40% login requests
2. 30% content requests
3. 20% banner requests
4. 10% announcement requests

**Load Pattern**:
- Ramp up over 5 minutes
- Sustain load for 30 minutes
- Ramp down over 2 minutes

### Scenario 4: Regional Distribution Test

**Objective**: Test performance across all supported countries

**Distribution**:
- Singapore: 25%
- Malaysia: 20%
- Hong Kong: 15%
- Indonesia: 15%
- China: 10%
- Vietnam: 8%
- Thailand: 7%

## Command Line Execution

### Basic Test Execution

```bash
# Run light load test
jmeter -n -t regional-bank-light-load.jmx -l results/light-load-results.jtl -e -o results/light-load-report/

# Run heavy load test
jmeter -n -t regional-bank-heavy-load.jmx -l results/heavy-load-results.jtl -e -o results/heavy-load-report/

# Run stress test
jmeter -n -t regional-bank-stress-test.jmx -l results/stress-test-results.jtl -e -o results/stress-test-report/
```

### Parameterized Execution

```bash
# Custom parameters
jmeter -n -t regional-bank-performance.jmx \
  -Jbase_url=http://staging.bank.com:8080 \
  -Jconcurrent_users=100 \
  -Jtest_duration=600 \
  -Jramp_up_time=120 \
  -l results/custom-test-results.jtl \
  -e -o results/custom-test-report/
```

### Distributed Testing

```bash
# Run on multiple servers
jmeter -n -t regional-bank-performance.jmx \
  -R server1.test.com,server2.test.com,server3.test.com \
  -l results/distributed-results.jtl \
  -e -o results/distributed-report/
```

## Performance Benchmarks

### Response Time SLAs

| API Endpoint | Target | Acceptable | Critical |
|--------------|--------|------------|----------|
| Login API | < 1.5s | < 2.0s | < 5.0s |
| Content API | < 0.8s | < 1.2s | < 3.0s |
| Banner API | < 0.5s | < 1.0s | < 2.0s |
| Announcement API | < 0.5s | < 1.0s | < 2.0s |

### Throughput Requirements

| Load Level | Concurrent Users | Target TPS | Duration |
|------------|------------------|------------|----------|
| Light | 10-25 | 50-100 | 5 min |
| Medium | 50-100 | 200-400 | 15 min |
| Heavy | 100-200 | 500-800 | 30 min |
| Stress | 200-500 | 800-1200 | 60 min |

### Resource Utilization Limits

| Metric | Warning | Critical |
|--------|---------|----------|
| CPU Usage | > 70% | > 85% |
| Memory Usage | > 80% | > 90% |
| Database Connections | > 70% | > 85% |
| Network I/O | > 70% | > 85% |

## Monitoring and Alerting

### Key Metrics to Monitor

```bash
# System metrics
- CPU utilization
- Memory usage
- Disk I/O
- Network throughput
- Database connection pool

# Application metrics
- Response times (avg, 95th, 99th percentile)
- Throughput (requests per second)
- Error rates
- Active sessions
- Queue depths
```

### Automated Test Execution Script

```bash
#!/bin/bash
# performance-test-runner.sh

# Set variables
TEST_PLAN="regional-bank-performance.jmx"
RESULTS_DIR="results/$(date +%Y%m%d-%H%M%S)"
BASE_URL=${1:-"http://localhost:8080"}
USERS=${2:-50}
DURATION=${3:-300}

# Create results directory
mkdir -p $RESULTS_DIR

# Run performance test
echo "Starting performance test..."
echo "Base URL: $BASE_URL"
echo "Concurrent Users: $USERS"
echo "Duration: $DURATION seconds"

jmeter -n -t $TEST_PLAN \
  -Jbase_url=$BASE_URL \
  -Jconcurrent_users=$USERS \
  -Jtest_duration=$DURATION \
  -l $RESULTS_DIR/results.jtl \
  -e -o $RESULTS_DIR/dashboard/

# Generate summary
echo "Test completed. Results saved to: $RESULTS_DIR"
echo "Dashboard available at: $RESULTS_DIR/dashboard/index.html"

# Check for errors
ERROR_COUNT=$(awk -F',' 'NR>1 && $8=="false" {count++} END {print count+0}' $RESULTS_DIR/results.jtl)
TOTAL_COUNT=$(awk -F',' 'NR>1 {count++} END {print count+0}' $RESULTS_DIR/results.jtl)
ERROR_RATE=$(echo "scale=2; $ERROR_COUNT * 100 / $TOTAL_COUNT" | bc)

echo "Error Rate: $ERROR_RATE%"

if (( $(echo "$ERROR_RATE > 5.0" | bc -l) )); then
  echo "WARNING: High error rate detected!"
  exit 1
fi
```

## Integration with CI/CD

### Jenkins Pipeline Integration

```groovy
pipeline {
    agent any
    
    parameters {
        choice(name: 'TEST_ENVIRONMENT', choices: ['dev', 'staging', 'prod'], description: 'Environment to test')
        choice(name: 'LOAD_LEVEL', choices: ['light', 'medium', 'heavy'], description: 'Load test level')
    }
    
    stages {
        stage('Setup') {
            steps {
                script {
                    env.BASE_URL = params.TEST_ENVIRONMENT == 'prod' ? 'https://api.bank.com' : "http://${params.TEST_ENVIRONMENT}.bank.com:8080"
                    env.USERS = params.LOAD_LEVEL == 'light' ? '25' : params.LOAD_LEVEL == 'medium' ? '100' : '200'
                }
            }
        }
        
        stage('Performance Test') {
            steps {
                sh """
                    ./performance-test-runner.sh ${env.BASE_URL} ${env.USERS} 600
                """
            }
        }
        
        stage('Publish Results') {
            steps {
                publishHTML([
                    allowMissing: false,
                    alwaysLinkToLastBuild: true,
                    keepAll: true,
                    reportDir: 'results/latest/dashboard',
                    reportFiles: 'index.html',
                    reportName: 'Performance Test Report'
                ])
            }
        }
    }
    
    post {
        always {
            archiveArtifacts artifacts: 'results/**/*', fingerprint: true
        }
        failure {
            emailext (
                subject: "Performance Test Failed - ${env.JOB_NAME} #${env.BUILD_NUMBER}",
                body: "Performance test failed. Check the build for details.",
                to: "${env.PERFORMANCE_TEAM_EMAIL}"
            )
        }
    }
}
```

This comprehensive JMeter testing suite provides complete performance testing coverage for the Regional Banking Application APIs with configurable load levels, detailed reporting, and CI/CD integration capabilities.

