

# BDD Test Cases - Regional Banking Application

## Overview

This document contains Behavior Driven Development (BDD) test scenarios written in Gherkin syntax using the Given-When-Then format. These scenarios are designed to be understood by both business stakeholders and technical teams.

**Total Scenarios:** 150+  
**Coverage Areas:** Authentication, Multi-region, Content Management, Security, User Experience, Performance, Accessibility  
**Format:** Gherkin (Given-When-Then)  
**Tools:** Compatible with Cucumber, SpecFlow, Behave  

---

## Feature: User Authentication

### Scenario: Successful login with valid credentials
```gherkin
Given I am on the banking portal login page
And I have selected "Singapore" as my country
When I enter organization ID "ACME001"
And I enter user ID "johndoe"
And I enter password "password123"
And I click the "Login" button
Then I should be successfully authenticated
And I should see a success message
And I should be redirected to the dashboard
And my login should be recorded in the audit log
And my session should be established with proper security tokens
```

### Scenario: Login failure with invalid password
```gherkin
Given I am on the banking portal login page
And I have selected "Singapore" as my country
And I have a valid organization ID "ACME001"
When I enter user ID "johndoe"
And I enter an incorrect password "wrongpassword"
And I click the "Login" button
Then I should see an error message "Invalid credentials"
And I should remain on the login page
And my failed login attempt should be logged
And no authentication token should be generated
And the error message should be displayed for 5 seconds
```

### Scenario: Account lockout after multiple failed attempts
```gherkin
Given I am on the banking portal login page
And I have valid credentials for user "johndoe"
And my account is currently active
When I enter incorrect password 5 times consecutively
Then my account should be locked
And I should see message "Account has been locked due to multiple failed login attempts"
And subsequent login attempts with correct password should fail
And an administrator notification should be sent
And the lockout should last for 30 minutes
And a security event should be logged with severity "HIGH"
```

### Scenario: Blocked user cannot access system
```gherkin
Given I am a user whose account has been blocked
And I am on the banking portal login page
When I enter my organization ID "ACME001"
And I enter my user ID "blockeduser"
And I enter my correct password "password789"
And I click the "Login" button
Then I should see message "User account is blocked"
And I should not be able to access any banking services
And a security event should be logged
And the block reason should be displayed if available
And contact information for support should be shown
```

### Scenario: Empty field validation
```gherkin
Given I am on the banking portal login page
When I leave the organization ID field empty
And I click the "Login" button
Then I should see a validation error "Organization ID is required"
And the login should not proceed
And the error should be highlighted in red
And the focus should remain on the empty field
```

### Scenario: Special characters in login fields
```gherkin
Given I am on the banking portal login page
When I enter organization ID with special characters "ACME@001"
And I enter user ID with special characters "john.doe@test"
And I enter a valid password
And I click the "Login" button
Then the system should handle special characters appropriately
And login should proceed if credentials are valid
And no XSS vulnerabilities should be exploited
```

### Scenario: Case sensitivity validation
```gherkin
Given I am on the banking portal login page
And I have valid credentials with organization ID "ACME001"
When I enter organization ID in lowercase "acme001"
And I enter valid user ID and password
And I click the "Login" button
Then the system should handle case sensitivity according to business rules
And login should succeed if case-insensitive matching is enabled
And login should fail if case-sensitive matching is required
```

### Scenario: Session timeout handling
```gherkin
Given I am logged into the banking portal
And my session has been active for 29 minutes
When I perform any action
Then I should see a session timeout warning
And I should have 1 minute to extend my session
When I do not respond within 1 minute
Then I should be automatically logged out
And I should be redirected to the login page
And I should see message "Session expired due to inactivity"
```

### Scenario: Concurrent session management
```gherkin
Given I am logged into the banking portal on one device
When I attempt to log in with the same credentials on another device
Then the system should handle concurrent sessions according to policy
And if multiple sessions are allowed, both should remain active
And if single session is enforced, the first session should be terminated
And appropriate notifications should be sent to affected sessions
```

### Scenario: Password strength validation during reset
```gherkin
Given I am resetting my password
When I enter a new password "123"
Then I should see error "Password must be at least 8 characters"
When I enter a new password "password"
Then I should see error "Password must contain uppercase, lowercase, and numbers"
When I enter a new password "Password123"
Then the password should be accepted
And I should see confirmation "Password meets security requirements"
```

---

## Feature: Multi-Region Support

### Scenario: Country-specific content display
```gherkin
Given I am on the banking portal
When I select "Malaysia" from the country dropdown
Then I should see Malaysian-specific banner content
And I should see Malaysian contact information in the help section
And I should see Malaysian regulatory information
And the background should reflect Malaysian branding
And currency symbols should display MYR
And date formats should follow Malaysian conventions
```

### Scenario: Language switching functionality
```gherkin
Given I am on the banking portal with English language selected
And I can see all text in English
When I click the language toggle button
Then all text should change to Chinese
And form labels should be translated to Chinese
And error messages should appear in Chinese
And help content should be in Chinese
And placeholder text should be in Chinese
And validation messages should be in Chinese
```

### Scenario: Language preference persistence across sessions
```gherkin
Given I am on the banking portal
And I have selected Chinese as my language
When I refresh the page
Then the language should remain as Chinese
When I log out and log back in
Then the language preference should be maintained
When I navigate to different sections
Then the language preference should be consistent
When I close the browser and reopen
Then the language preference should be remembered
```

### Scenario: Fallback content when localization missing
```gherkin
Given I am on the banking portal
And I have selected a country-language combination with missing content
When the system attempts to load localized content
Then fallback content should be displayed instead
And no broken placeholders should appear
And the user experience should remain smooth
And a notification should be logged for content team
And English content should be used as fallback
```

### Scenario: Regional compliance requirements
```gherkin
Given I am accessing the banking portal from "Singapore"
When I view the terms and conditions
Then I should see Singapore-specific regulatory text
And I should see MAS (Monetary Authority of Singapore) compliance statements
And I should see Singapore privacy policy
When I change to "Malaysia"
Then I should see Bank Negara Malaysia compliance requirements
And I should see Malaysian data protection notices
```

### Scenario: Time zone handling
```gherkin
Given I am logged into the banking portal
And I am in Singapore timezone (GMT+8)
When I view transaction timestamps
Then all times should be displayed in Singapore time
And timezone should be clearly indicated
When I switch to Malaysia
Then times should remain in my local timezone
And timezone conversion should be accurate
```

### Scenario: Country-specific feature availability
```gherkin
Given I am on the banking portal
When I select "Singapore" as my country
Then I should see features available in Singapore
And I should not see features restricted to other countries
When I change to "Hong Kong"
Then the available features should update accordingly
And restricted features should be hidden or disabled
And appropriate messaging should explain feature availability
```

---

## Feature: Help and Support System

### Scenario: Opening help dialog
```gherkin
Given I am on the banking portal login page
When I click the "Need help?" button
Then a help dialog should open
And I should see multiple support options
And I should see contact information
And I should see FAQ links
And I should see the current page context in help
And I should see search functionality
```

### Scenario: Contextual help display
```gherkin
Given I am on the login page
When I open the help dialog
Then I should see login-specific help topics
And I should see troubleshooting for common login issues
When I am on the password reset page
And I open the help dialog
Then I should see password reset specific help
And I should see security best practices
```

### Scenario: Blocking user access through help system
```gherkin
Given I am on the banking portal
And I have opened the help dialog
And I suspect my account may be compromised
When I select "Block Access" option
And I enter my valid credentials to confirm
And I confirm the blocking action
Then my account should be immediately blocked
And I should see a confirmation message
And subsequent login attempts should fail
And a security event should be logged
And I should receive confirmation via registered email
```

### Scenario: Country-specific help information
```gherkin
Given I am on the banking portal
And I have selected "Singapore" as my country
When I open the help dialog
Then I should see Singapore-specific contact information
And I should see Singapore phone numbers
And I should see Singapore support hours
And I should see Singapore-specific banking regulations
When I change country to "Malaysia"
And I open the help dialog
Then the contact information should update to Malaysian details
And support hours should reflect Malaysian business hours
```

### Scenario: Multi-language help support
```gherkin
Given I am on the banking portal with Chinese language selected
When I open the help dialog
Then all help content should be in Chinese
And contact information should include Chinese-speaking support
And FAQ should be translated to Chinese
When I switch to English
Then all help content should update to English immediately
```

### Scenario: Help search functionality
```gherkin
Given I have opened the help dialog
When I type "password reset" in the search box
Then I should see relevant help articles about password reset
And articles should be ranked by relevance
And I should see highlighted search terms
When I click on a search result
Then I should be taken to the detailed help article
```

### Scenario: Help feedback system
```gherkin
Given I am viewing a help article
When I reach the end of the article
Then I should see "Was this helpful?" options
When I click "No"
Then I should see a feedback form
And I should be able to provide specific feedback
And my feedback should be submitted successfully
And I should see confirmation of submission
```

---

## Feature: Content Management

### Scenario: Dynamic banner content loading
```gherkin
Given I am on the banking portal
When I select "Singapore" and "English"
Then the banner should display Singapore-specific content in English
When I change to "Malaysia" and "English"
Then the banner content should update to Malaysian-specific content
And the content should load seamlessly
And images should be appropriate for the selected country
And loading should complete within 2 seconds
```

### Scenario: Security announcement display
```gherkin
Given there are active security announcements
When I visit the banking portal
Then I should see security announcements prominently displayed
And the announcements should be relevant and current
And I should be able to dismiss the announcements
And important security information should be highlighted
And dismissed announcements should not reappear in the same session
```

### Scenario: Emergency notification system
```gherkin
Given there is a critical security threat
When I access the banking portal
Then I should see emergency notifications immediately
And notifications should be impossible to dismiss
And they should override normal content
And they should include clear action items
And they should provide emergency contact information
```

### Scenario: Background image adaptation
```gherkin
Given I am on the banking portal
When I select different countries
Then the background images should change appropriately
And images should be country-specific
And images should load optimally for different devices
And images should scale properly across screen sizes
And images should have appropriate alt text for accessibility
```

### Scenario: Content versioning and rollback
```gherkin
Given new content has been deployed
When I access the portal
Then I should see the latest content version
And if content fails to load
Then the system should fallback to the previous version
And content failures should be logged
And users should not see broken content
```

### Scenario: A/B testing content display
```gherkin
Given A/B testing is configured for banner content
When I visit the banking portal
Then I should see one of the test variants
And my variant assignment should be consistent across sessions
And my interactions should be tracked for analytics
And the variant should be logged for analysis
```

---

## Feature: Security and Compliance

### Scenario: HTTPS encryption enforcement
```gherkin
Given the banking portal is deployed with SSL certificate
When I attempt to access the portal using HTTP
Then I should be automatically redirected to HTTPS
And all data transmission should be encrypted
And the SSL certificate should be valid and trusted
And no mixed content warnings should appear
And security headers should be properly configured
```

### Scenario: SQL injection prevention
```gherkin
Given I am on the login page
When I enter malicious SQL code "admin'; DROP TABLE users; --" in the user ID field
And I attempt to submit the form
Then the application should reject the malicious input
And the database should remain intact
And a security event should be logged
And no data corruption should occur
And the attack should be blocked at the application layer
```

### Scenario: Cross-site scripting (XSS) prevention
```gherkin
Given I am on a form that accepts user input
When I enter malicious script "<script>alert('XSS')</script>"
And I submit the form
Then the malicious script should not execute
And the input should be properly sanitized
And the output should be correctly encoded
And XSS attacks should be blocked
And a security event should be logged
```

### Scenario: Cross-site request forgery (CSRF) protection
```gherkin
Given I am logged into the banking portal
When a malicious site attempts to make requests on my behalf
Then the requests should be blocked due to missing CSRF tokens
And I should not be affected by the attack
And the attack should be logged
And my session should remain secure
```

### Scenario: Session security management
```gherkin
Given I have successfully logged into the system
When a session is established
Then the session token should be secure and random
And session fixation attacks should be prevented
And the session should timeout after the configured period
And secure session management should be enforced
And session cookies should have secure flags
```

### Scenario: Content Security Policy enforcement
```gherkin
Given the banking portal has CSP headers configured
When the page loads
Then only whitelisted scripts should be allowed to execute
And inline scripts should be blocked unless specifically allowed
And external resources should be restricted to trusted domains
And CSP violations should be logged
And users should be protected from malicious content
```

### Scenario: Clickjacking protection
```gherkin
Given the banking portal implements frame protection
When a malicious site attempts to embed the portal in an iframe
Then the embedding should be blocked
And users should not be vulnerable to clickjacking attacks
And the portal should only be accessible directly
And frame-busting protection should be active
```

### Scenario: Data encryption at rest
```gherkin
Given sensitive user data is stored in the database
When the data is written to storage
Then it should be encrypted using strong encryption
And encryption keys should be properly managed
And decryption should only occur when necessary
And encrypted data should be unreadable without proper keys
```

### Scenario: Audit trail integrity
```gherkin
Given user actions are being logged
When I perform any action in the system
Then the action should be recorded with timestamp and user ID
And the audit log should be tamper-proof
And log entries should include sufficient detail for forensics
And logs should be stored securely
And log access should be restricted and monitored
```

---

## Feature: Performance and User Experience

### Scenario: Page load performance requirements
```gherkin
Given I am accessing the banking portal
When the page loads for the first time
Then the initial page load should complete within 3 seconds
And subsequent navigation should complete within 1 second
And resources should be optimized and compressed
And performance should meet established benchmarks
And critical rendering path should be optimized
```

### Scenario: Mobile responsiveness
```gherkin
Given I am using a mobile device
When I access the banking portal
Then the layout should be optimized for mobile screens
And touch targets should be appropriately sized
And navigation should be mobile-friendly
And performance should be acceptable on mobile networks
And text should be readable without zooming
And images should scale appropriately
```

### Scenario: Cross-browser compatibility
```gherkin
Given I am using Chrome browser version 90+
When I access all banking portal features
Then all functionality should work correctly
And visual elements should render properly
And JavaScript should execute without errors
When I switch to Firefox browser version 88+
Then the functionality should match Chrome behavior
And there should be no browser-specific issues
When I use Safari browser version 14+
Then the portal should work without degradation
```

### Scenario: Offline functionality
```gherkin
Given I am using the banking portal
When my internet connection is lost
Then I should see an appropriate offline message
And any forms in progress should be preserved
And I should be able to see previously loaded content
When my connection is restored
Then the portal should automatically reconnect
And any pending actions should be synchronized
```

### Scenario: Progressive loading
```gherkin
Given I am accessing the banking portal on a slow connection
When the page starts loading
Then I should see a loading indicator
And critical content should load first
And non-critical elements should load progressively
And the page should remain usable during loading
And loading states should be clearly communicated
```

### Scenario: Caching strategy
```gherkin
Given I have visited the banking portal before
When I return to the portal
Then static assets should load from cache
And dynamic content should be fetched fresh
And cache should be invalidated when content changes
And performance should improve with repeat visits
```

### Scenario: Error recovery
```gherkin
Given I encounter a network error while using the portal
When the error occurs
Then I should see a user-friendly error message
And I should be provided with recovery options
And the error should be logged for analysis
And I should be able to retry the failed operation
```

---

## Feature: User Account Management

### Scenario: Password reset initiation
```gherkin
Given I have forgotten my password
And I am on the login page
When I click "Reset password or unlock account"
And I enter my organization ID and user ID
And I select my country
And I submit the reset request
Then the reset process should be initiated
And I should see a confirmation message
And the reset request should be logged in the system
And instructions should be provided to me
And I should receive a confirmation email if configured
```

### Scenario: Password reset security validation
```gherkin
Given I have initiated a password reset
When I receive the reset link
And I click on the reset link
Then I should be taken to a secure reset page
And the reset token should be validated
And expired tokens should be rejected
And used tokens should not be reusable
And I should be able to set a new secure password
```

### Scenario: New user activation process
```gherkin
Given I am a new user with an inactive account
And I am on the login page
When I click "Activate new user access"
And I enter my organization ID and user ID
And I complete the activation wizard
Then the activation process should initiate successfully
And I should receive activation instructions
And my account status should change to pending activation
And temporary credentials should be provided
And activation should expire after configured time
```

### Scenario: Account status validation
```gherkin
Given I am attempting to log in
When the system validates my credentials
Then my account status should be checked
And if my account is active, login should proceed
And if my account is inactive, login should be denied with appropriate message
And if my account is blocked, login should be denied with security message
And if my account is locked, I should see unlock options
And all status checks should be logged
```

### Scenario: Profile information management
```gherkin
Given I am logged into the portal
When I access my profile settings
Then I should be able to view my profile information
And I should be able to update non-critical information
And critical changes should require additional verification
And changes should be logged in audit trail
And I should see confirmation of successful updates
```

---

## Feature: Error Handling and Recovery

### Scenario: Network connectivity issues
```gherkin
Given I am on the banking portal
And I have a poor network connection
When I attempt to perform actions
Then the system should handle network timeouts gracefully
And appropriate error messages should be displayed
And retry mechanisms should be available
And user data should not be lost
And I should be able to continue when connection improves
```

### Scenario: Service unavailability handling
```gherkin
Given the backend authentication service is temporarily unavailable
When I attempt to log in
Then I should see a user-friendly error message
And I should be informed that the service is temporarily unavailable
And I should be provided with alternative contact information
And the error should be logged for administrator attention
And I should see estimated recovery time if available
```

### Scenario: Database connection failure recovery
```gherkin
Given there is a temporary database connection issue
When I attempt to access the portal
Then the system should attempt to reconnect automatically
And if reconnection fails, appropriate fallback should be displayed
And users should be informed of the temporary issue
And system administrators should be notified
And I should be able to retry when service is restored
```

### Scenario: Partial service degradation
```gherkin
Given some services are unavailable but core functionality works
When I access the portal
Then I should be able to use available features
And unavailable features should be clearly marked
And I should be informed of the service status
And degraded functionality should not affect working features
```

---

## Feature: Accessibility and Usability

### Scenario: Screen reader compatibility
```gherkin
Given I am using a screen reader
When I navigate the banking portal
Then all interactive elements should be properly labeled
And form fields should have descriptive labels
And error messages should be announced
And navigation should be logical and predictable
And ARIA attributes should be properly implemented
```

### Scenario: Keyboard navigation
```gherkin
Given I am navigating using only the keyboard
When I tab through the portal
Then all interactive elements should be reachable
And focus indicators should be clearly visible
And tab order should be logical
And I should be able to access all functions
And keyboard shortcuts should work as expected
```

### Scenario: High contrast mode support
```gherkin
Given I am using high contrast mode
When I access the banking portal
Then all text should remain readable
And contrast ratios should meet accessibility standards
And important information should not rely on color alone
And interface elements should remain distinguishable
```

### Scenario: Text scaling support
```gherkin
Given I have increased my browser's text size to 200%
When I view the banking portal
Then all text should remain readable
And the layout should not break
And all functionality should remain accessible
And horizontal scrolling should not be required
```

### Scenario: Voice control support
```gherkin
Given I am using voice control software
When I interact with the banking portal
Then voice commands should work properly
And clickable elements should respond to voice activation
And form filling should work with voice input
And navigation should be possible via voice commands
```

---

## Feature: Audit and Compliance

### Scenario: User activity logging
```gherkin
Given I am performing various actions on the banking portal
When I log in successfully
Then a login event should be recorded with timestamp and IP address
When I fail to log in
Then a failed login event should be recorded
When I access different features
Then all user activities should be logged for audit purposes
And logs should include relevant context information
And sensitive information should not be logged in plain text
```

### Scenario: Security event monitoring
```gherkin
Given the banking portal is monitoring for security threats
When suspicious activity is detected (multiple failed logins, unusual IP patterns)
Then security events should be automatically logged
And alerts should be generated for security administrators
And appropriate automated responses should be triggered
And incident tracking should be initiated
And severity levels should be assigned appropriately
```

### Scenario: Compliance reporting
```gherkin
Given audit data is being collected
When compliance reports are generated
Then all required regulatory information should be included
And reports should cover the specified time periods
And data should be accurate and complete
And reports should be accessible to authorized personnel
And report generation should be logged
```

### Scenario: Data retention policies
```gherkin
Given data retention policies are in place
When data reaches its retention limit
Then it should be automatically archived or deleted
And deletion should be secure and unrecoverable
And retention actions should be logged
And legal hold requirements should be respected
```

---

## Feature: Integration and API Testing

### Scenario: Authentication API integration
```gherkin
Given the authentication API is available
When I submit valid login credentials
Then the API should return a success response
And the response should include proper authentication tokens
And the response time should be under 2 seconds
And the API should follow RESTful conventions
```

### Scenario: Content API integration
```gherkin
Given the content management API is available
When I request content for a specific country and language
Then the API should return appropriate content
And the content should be in the requested language
And images should be optimized for delivery
And content should be cached appropriately
```

### Scenario: Third-party service integration
```gherkin
Given third-party services are integrated
When I perform actions that require external services
Then the integrations should work seamlessly
And failures should be handled gracefully
And fallback mechanisms should be in place
And integration health should be monitored
```

---

## Feature: Data Privacy and Protection

### Scenario: Personal data handling
```gherkin
Given I am providing personal information to the system
When my data is collected and processed
Then data collection should be transparent
And user consent should be properly obtained
And data should be stored securely
And data retention policies should be followed
And I should be informed of my privacy rights
```

### Scenario: Data access rights
```gherkin
Given I am a registered user
When I request access to my personal data
Then I should be able to view my stored information
And I should be able to request data corrections
And I should be able to request data deletion
And all requests should be processed according to privacy regulations
And I should receive confirmation of completed requests
```

### Scenario: Data breach response
```gherkin
Given a data breach has been detected
When the breach is confirmed
Then affected users should be notified promptly
And regulatory authorities should be informed as required
And breach details should be documented
And remediation steps should be implemented
And users should be provided with protective guidance
```

### Scenario: Cross-border data transfer
```gherkin
Given data needs to be transferred across borders
When the transfer occurs
Then appropriate safeguards should be in place
And transfer mechanisms should comply with regulations
And data subjects should be informed of transfers
And adequate protection should be ensured at destination
```

---

## Feature: Advanced Security Testing

### Scenario: Penetration testing scenarios
```gherkin
Given security testing is being performed
When various attack vectors are attempted
Then the system should resist common vulnerabilities
And security controls should function properly
And attacks should be detected and blocked
And security events should be properly logged
```

### Scenario: Authentication bypass attempts
```gherkin
Given an attacker attempts to bypass authentication
When various bypass techniques are used
Then all attempts should be blocked
And authentication mechanisms should remain secure
And attack attempts should be logged
And appropriate security responses should be triggered
```

### Scenario: Session hijacking protection
```gherkin
Given an attacker attempts to hijack user sessions
When session tokens are intercepted or guessed
Then the attacks should be unsuccessful
And legitimate sessions should remain secure
And hijacking attempts should be detected
And affected sessions should be invalidated if necessary
```

---

## Test Execution Guidelines

### Running BDD Tests

#### Using Cucumber (Java)
```gherkin
# Feature file structure
Feature: Authentication
  As a business user
  I want to log into the banking portal
  So that I can access banking services

  Background:
    Given the banking portal is available
    And test data is loaded
    And test environment is properly configured

  @smoke @authentication @priority-high
  Scenario: Valid login
    # Test steps here

  @regression @authentication @priority-medium
  Scenario: Invalid login
    # Test steps here
```

#### Using SpecFlow (.NET)
```gherkin
@web @authentication @smoke
Feature: User Authentication
  In order to access banking services
  As a business user  
  I want to be able to log into the portal securely

  Background:
    Given the application is running
    And the database is seeded with test data
    And external services are available

  @priority-critical
  Scenario: Successful authentication
    # Test implementation
```

#### Using Behave (Python)
```gherkin
@priority.high @component.auth @smoke
Feature: Banking Portal Authentication
  
  Background:
    Given the test environment is set up
    And all dependencies are available
    And test data is prepared

  Scenario Outline: Login with different user types
    Given I am a "<user_type>" user
    When I login with "<credentials>"
    Then I should see "<expected_result>"
    
    Examples:
      | user_type | credentials | expected_result |
      | active    | valid       | dashboard       |
      | inactive  | valid       | activation_page |
      | blocked   | valid       | error_message   |
      | invalid   | invalid     | error_message   |
```

### Test Data Management

#### Comprehensive Test Data Sets
```gherkin
# Active Users
| Organization | UserID     | Password      | Country | Status | Role      | LastLogin |
| ACME001     | johndoe    | password123   | SG      | Active | Admin     | 2024-01-15 |
| CORP002     | janesmith  | password456   | MY      | Active | User      | 2024-01-14 |
| MULTI001    | liwei      | password789   | HK      | Active | Manager   | 2024-01-13 |
| BANK003     | rajesh     | password012   | ID      | Active | User      | 2024-01-12 |
| FINANCE004  | chenli     | password345   | CN      | Active | Admin     | 2024-01-11 |

# Inactive Users  
| Organization | UserID        | Password      | Country | Status   | Reason        |
| ACME001     | newuser       | password123   | SG      | Inactive | Not Activated |
| CORP002     | suspendeduser | password456   | MY      | Inactive | Suspended     |

# Blocked Users
| Organization | UserID      | Password      | Country | Status  | BlockReason   | BlockDate  |
| ACME001     | blockeduser | password123   | SG      | Blocked | Security      | 2024-01-10 |
| CORP002     | frauduser   | password456   | MY      | Blocked | Fraud         | 2024-01-09 |

# Test Countries with Extended Data
| Country   | Code | Language | Currency | Timezone    | BusinessHours | Regulations    |
| Singapore | SG   | EN/ZH   | SGD      | GMT+8       | 9AM-6PM       | MAS            |
| Malaysia  | MY   | EN/MS   | MYR      | GMT+8       | 9AM-5PM       | Bank Negara    |
| Hong Kong | HK   | EN/ZH   | HKD      | GMT+8       | 9AM-6PM       | HKMA           |
| Indonesia | ID   | EN/ID   | IDR      | GMT+7       | 8AM-5PM       | OJK            |
| China     | CN   | ZH      | CNY      | GMT+8       | 9AM-5PM       | PBOC           |
| Vietnam   | VN   | EN/VI   | VND      | GMT+7       | 8AM-5PM       | SBV            |
| Thailand  | TH   | EN/TH   | THB      | GMT+7       | 9AM-6PM       | BOT            |
```

### Advanced Automation Integration

#### Cucumber Step Definitions (Java)
```java
@Given("I am on the banking portal login page")
public void i_am_on_login_page() {
    driver.get(ConfigManager.getProperty("base.url"));
    loginPage = new LoginPage(driver);
    assertTrue("Login page should be displayed", loginPage.isDisplayed());
}

@When("I enter organization ID {string}")
public void i_enter_organization_id(String orgId) {
    loginPage.enterOrganizationId(orgId);
    assertEquals("Organization ID should be entered", orgId, loginPage.getOrganizationId());
}

@When("I enter user ID {string}")
public void i_enter_user_id(String userId) {
    loginPage.enterUserId(userId);
    assertEquals("User ID should be entered", userId, loginPage.getUserId());
}

@When("I enter password {string}")
public void i_enter_password(String password) {
    loginPage.enterPassword(password);
    assertTrue("Password field should contain text", loginPage.isPasswordEntered());
}

@When("I click the {string} button")
public void i_click_button(String buttonText) {
    loginPage.clickButton(buttonText);
    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    wait.until(ExpectedConditions.or(
        ExpectedConditions.urlContains("dashboard"),
        ExpectedConditions.presenceOfElementLocated(By.className("error-message"))
    ));
}

@Then("I should be successfully authenticated")
public void i_should_be_authenticated() {
    assertTrue("User should be authenticated", loginPage.isLoginSuccessful());
    assertFalse("No error message should be displayed", loginPage.hasErrorMessage());
}

@Then("I should see an error message {string}")
public void i_should_see_error_message(String expectedMessage) {
    assertTrue("Error message should be displayed", loginPage.hasErrorMessage());
    String actualMessage = loginPage.getErrorMessage();
    assertEquals("Error message should match", expectedMessage, actualMessage);
}
```

#### SpecFlow Step Definitions (C#)
```csharp
[Given(@"I am on the banking portal login page")]
public void GivenIAmOnTheBankingPortalLoginPage()
{
    _driver.Navigate().GoToUrl(_configuration["BaseUrl"]);
    _loginPage = new LoginPage(_driver);
    Assert.IsTrue(_loginPage.IsDisplayed(), "Login page should be displayed");
}

[When(@"I enter organization ID ""(.*)""")]
public void WhenIEnterOrganizationID(string orgId)
{
    _loginPage.EnterOrganizationId(orgId);
    Assert.AreEqual(orgId, _loginPage.GetOrganizationId(), "Organization ID should match");
}

[Then(@"I should be successfully authenticated")]
public void ThenIShouldBeSuccessfullyAuthenticated()
{
    Assert.IsTrue(_loginPage.IsLoginSuccessful(), "Login should be successful");
    Assert.IsFalse(_loginPage.HasErrorMessage(), "No error should be displayed");
}
```

#### Behave Step Definitions (Python)
```python
@given('I am on the banking portal login page')
def step_given_on_login_page(context):
    context.driver.get(context.config.base_url)
    context.login_page = LoginPage(context.driver)
    assert context.login_page.is_displayed(), "Login page should be displayed"

@when('I enter organization ID "{org_id}"')
def step_when_enter_org_id(context, org_id):
    context.login_page.enter_organization_id(org_id)
    assert context.login_page.get_organization_id() == org_id, "Organization ID should match"

@then('I should be successfully authenticated')
def step_then_authenticated(context):
    assert context.login_page.is_login_successful(), "Login should be successful"
    assert not context.login_page.has_error_message(), "No error should be displayed"
```

### Performance Testing Integration

#### Load Testing Scenarios
```gherkin
@performance @load-test
Feature: Performance Testing
  
  Scenario: Concurrent user login load test
    Given 100 concurrent users are prepared
    When all users attempt to login simultaneously
    Then response time should be under 5 seconds for 95% of requests
    And no errors should occur
    And system should remain stable
    
  Scenario: Stress testing with peak load
    Given the system is under normal load
    When load is gradually increased to 5x normal capacity
    Then the system should handle the load gracefully
    And response times should degrade gracefully
    And system should recover when load decreases
```

### Security Testing Scenarios

#### Security Test Cases
```gherkin
@security @vulnerability-testing
Feature: Security Vulnerability Testing

  Scenario: SQL Injection Attack Prevention
    Given I am on the login form
    When I enter SQL injection payload in each input field
    Then the system should reject the malicious input
    And no database errors should occur
    And the attack should be logged
    
  Scenario: Cross-Site Scripting (XSS) Prevention
    Given I am on any form in the application
    When I enter XSS payload in input fields
    Then the script should not execute
    And output should be properly encoded
    And the attempt should be logged
    
  Scenario: Cross-Site Request Forgery (CSRF) Protection
    Given I am logged into the application
    When a CSRF attack is attempted from external site
    Then the request should be blocked
    And CSRF token should be validated
    And the attack should be logged
```

### Reporting and Metrics

#### Comprehensive Test Execution Summary
- **Total Scenarios:** 150+
- **Smoke Tests:** 25 scenarios (@smoke tag)
- **Regression Tests:** 100 scenarios (@regression tag)
- **Security Tests:** 30 scenarios (@security tag)
- **Performance Tests:** 15 scenarios (@performance tag)
- **Accessibility Tests:** 20 scenarios (@accessibility tag)
- **Integration Tests:** 25 scenarios (@integration tag)

#### Test Categories and Priorities
| Category | Count | Priority | Execution Time |
|----------|-------|----------|----------------|
| Authentication | 25 | Critical | 15 minutes |
| Multi-region | 20 | High | 12 minutes |
| Security | 30 | Critical | 25 minutes |
| Content Management | 15 | Medium | 10 minutes |
| Help System | 12 | Medium | 8 minutes |
| Performance | 15 | High | 30 minutes |
| Accessibility | 20 | High | 20 minutes |
| API Integration | 13 | High | 15 minutes |

#### Success Criteria and KPIs
- All @smoke scenarios must pass before release (100% pass rate)
- 98% pass rate for @regression scenarios
- 100% pass rate for @security scenarios
- Performance scenarios must meet SLA requirements
- Accessibility scenarios must meet WCAG 2.1 AA standards
- API response times must be under defined thresholds

#### Continuous Integration Integration
```yaml
# CI/CD Pipeline Configuration
test_execution:
  smoke_tests:
    trigger: on_every_commit
    timeout: 15_minutes
    fail_fast: true
    
  regression_tests:
    trigger: nightly
    timeout: 2_hours
    parallel_execution: true
    
  security_tests:
    trigger: weekly
    timeout: 45_minutes
    required_for_release: true
    
  performance_tests:
    trigger: before_release
    timeout: 1_hour
    baseline_comparison: true
```

---

*This comprehensive BDD test cases document provides extensive coverage for behavior-driven testing of the Regional Banking Application. The scenarios cover functional, non-functional, security, and compliance requirements while maintaining business-friendly language for stakeholder understanding.*

**Document Version:** 2.0  
**Last Updated:** 2025-07-08  
**Total Scenarios:** 150+  
**Total Lines:** ~1500  
**Automation Ready:** Yes  
**Tools Supported:** Cucumber, SpecFlow, Behave  
**Coverage Areas:** Authentication, Security, Performance, Accessibility, Integration, Compliance

