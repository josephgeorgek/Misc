# Enterprise Multi-Region Application - Complete Lovable Template

## 🚀 Template Overview

This Lovable template provides a production-ready enterprise application with multi-country/region support, localization, and comprehensive backend integration. Perfect for any business requiring robust user management, regional customization, and scalable architecture.

**Use this prompt structure**: "I want to create a [APPLICATION_TYPE] similar to this enterprise template."

## 📋 Complete Feature Set

### ✅ Frontend (React + TypeScript + MUI)
- **Framework**: React 18 with TypeScript, Vite build tool
- **Styling**: Tailwind CSS + Shadcn/UI components + Material-UI integration
- **Features**: Responsive design, multi-country/language support, dynamic content
- **Authentication**: Organization-based login with JWT tokens
- **UI Components**: Country selector, language toggle, help dialogs, progress indicators

### ✅ Backend (Spring Boot + Java)
- **Framework**: Spring Boot 3.x with Java 17+
- **Database**: H2 in-memory with PostgreSQL production placeholder
- **APIs**: RESTful endpoints with Swagger documentation
- **Security**: JWT authentication, CORS configuration, password validation
- **Features**: User management, content management, account blocking

### ✅ Database & Mock Data
- **Development**: H2 in-memory database with console access
- **Production**: PostgreSQL configuration placeholder
- **Mock Data**: 7 countries/regions (SG, MY, HK, ID, CN, VN, TH) with test users
- **Schema**: Use case management, content management, localization support

### ✅ Multi-Country & Language Support
- **Countries/Regions**: Singapore, Malaysia, Hong Kong, Indonesia, China, Vietnam, Thailand
- **Languages**: English (EN) and Chinese (ZH)
- **Localization**: Dynamic content loading, country-specific configurations
- **Contact Info**: Country-specific help and support information

## 🎯 Perfect For Applications

- **Enterprise Applications**: Corporate portals, B2B platforms, employee systems
- **Multi-region Systems**: Applications serving multiple countries/regions
- **Secure Platforms**: Systems requiring robust authentication and user management
- **Corporate Tools**: HR systems, procurement platforms, business management tools
- **Service Platforms**: Customer service, support systems, management dashboards
- **Financial Services**: Banking, fintech, payment systems, investment platforms

## 📁 Complete Project Structure

```
Frontend (React + TypeScript + MUI):
├── src/components/
│   ├── AppLogo.tsx                   # Customizable branding
│   ├── CountrySelector.tsx           # Multi-country support
│   ├── LanguageToggle.tsx            # Language switching
│   ├── NeedHelpDialog.tsx            # Help and support
│   ├── [FeatureName]Dialog.tsx       # 📸 Screenshot-based dialogs
│   ├── [Workflow]Wizard.tsx          # 📸 Multi-step processes
│   ├── [Action]Component.tsx         # 📸 Action-based components
│   └── ui/ (Shadcn components)
├── src/pages/
│   ├── Index.tsx                     # Main entry page
│   ├── Dashboard.tsx                 # Main application view
│   ├── [FeaturePage].tsx             # 📸 Feature-specific pages
│   ├── [ManagementPage].tsx          # 📸 Management interfaces
│   └── NotFound.tsx                  # 404 error page
├── src/services/
│   ├── AuthService.ts                # Authentication logic
│   ├── ContentService.ts             # Dynamic content
│   ├── ConfigService.ts              # Configuration management
│   ├── [FeatureName]Service.ts       # 📸 Feature-specific services
│   ├── [DataType]Service.ts          # 📸 Data management services
│   └── SecurityNoticeService.ts      # Security announcements
└── src/config/
    └── AppConfig.ts                  # Application configuration

Backend (Spring Boot + Java):
├── src/main/java/com/enterprise/regional/
│   ├── controller/
│   │   ├── AuthController.java       # Authentication endpoints
│   │   ├── ContentController.java    # Content management
│   │   ├── [Feature]Controller.java  # 📸 Feature-specific endpoints
│   │   └── [Entity]Controller.java   # 📸 Entity management endpoints
│   ├── entity/
│   │   ├── User.java                 # User entity
│   │   ├── ContentData.java          # Content entity
│   │   ├── [BusinessEntity].java     # 📸 Business-specific entities
│   │   └── [DataModel].java          # 📸 Application data models
│   ├── repository/
│   │   ├── UserRepository.java       # User data access
│   │   ├── ContentDataRepository.java
│   │   ├── [Entity]Repository.java   # 📸 Entity repositories
│   │   └── [Feature]Repository.java  # 📸 Feature repositories
│   ├── services/
│   │   ├── AuthService.java          # Business logic
│   │   ├── ContentService.java       # Content logic
│   │   ├── [Feature]Service.java     # 📸 Feature business logic
│   │   └── [Process]Service.java     # 📸 Process management
│   └── config/
│       ├── CorsConfig.java           # CORS configuration
│       └── SwaggerConfig.java        # API documentation
└── src/main/resources/
    ├── application.properties        # Configuration
    ├── schema.sql                   # Database schema
    └── data.sql                     # Mock data
```

## 🔧 Key APIs & Endpoints (Generic Examples)

### Authentication Endpoints
```
POST /{country}/api/v1/user-login
- User authentication endpoint
- Request: {"organizationId": "ORG001", "userId": "USER123", "password": "password123"}
- Response: {"success": true, "token": "jwt-token", "country": "sg"}

POST /{country}/api/v1/account-action
- Account management actions
- Response: {"status": "success", "message": "Action completed successfully"}

POST /{country}/api/v1/password-reset
- Password reset initiation
- Request: {"organizationId": "ORG001", "userId": "USER123"}

POST /{country}/api/v1/user-registration
- New user registration/activation
- Request: {"organizationId": "ORG001", "userId": "NEWUSER"}
```

### Content Management Endpoints
```
GET /{country}/content/v1/{language}/common/banner/content.json
- Localized banner content
- Response: {"title": "Welcome", "subtitle": "Enterprise services", "content": "..."}

GET /{country}/content/v1/{language}/common/images/background.json
- Background image configuration
- Response: {"backgroundUrl": "/path/to/image.jpg", "content": "metadata"}

GET /{country}/content/v1/{language}/announcements/latest.json
- Latest announcements
- Response: {"title": "Notice", "content": "Important information", "type": "info"}
```

### 📸 Feature-Specific Endpoints (Placeholder Examples)
```
GET /{country}/api/v1/[feature-name]/list
- List feature items
- Response: {"items": [...], "total": 100, "page": 1}

POST /{country}/api/v1/[feature-name]/create
- Create new feature item
- Request: {"name": "Item Name", "data": {...}}

PUT /{country}/api/v1/[feature-name]/{id}/update
- Update existing item
- Request: {"id": "123", "updates": {...}}

DELETE /{country}/api/v1/[feature-name]/{id}/remove
- Remove item
- Response: {"status": "success", "message": "Item removed"}
```

## 🗄️ Database Schema & Mock Data (Generic Examples)

### User Management Table
```sql
CREATE TABLE users (
    id BIGINT PRIMARY KEY,
    organisation_id VARCHAR(255) NOT NULL,
    user_id VARCHAR(255) NOT NULL,
    password VARCHAR(255) NOT NULL,
    country VARCHAR(10) NOT NULL,
    active BOOLEAN DEFAULT true,
    blocked BOOLEAN DEFAULT false,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### Sample Test Users (All Countries)
```sql
-- Singapore (SG)
INSERT INTO users VALUES (1, 'CORP001', 'ADMIN001', 'password123', 'SG', true, false, NOW());
INSERT INTO users VALUES (2, 'CORP002', 'USER001', 'password456', 'SG', true, false, NOW());

-- Malaysia (MY)
INSERT INTO users VALUES (3, 'CORP001', 'MANAGER001', 'password123', 'MY', true, false, NOW());
INSERT INTO users VALUES (4, 'CORP002', 'STAFF001', 'password456', 'MY', true, false, NOW());

-- Similar entries for HK, ID, CN, VN, TH...
-- Blocked user example
INSERT INTO users VALUES (15, 'BLOCKED001', 'BLOCKED', 'password123', 'SG', false, true, NOW());
```

### Content Management Table
```sql
CREATE TABLE content_data (
    id BIGINT PRIMARY KEY,
    country VARCHAR(10) NOT NULL,
    language VARCHAR(10) NOT NULL,
    content_type VARCHAR(50) NOT NULL,
    content_key VARCHAR(255) NOT NULL,
    content_value TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### 📸 Generic Business Entity Tables (Placeholder Examples)
```sql
-- Example: Product/Service management
CREATE TABLE business_items (
    id BIGINT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    category VARCHAR(100),
    country VARCHAR(10) NOT NULL,
    status VARCHAR(50) DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Example: Transaction/Activity log
CREATE TABLE activity_log (
    id BIGINT PRIMARY KEY,
    user_id VARCHAR(255) NOT NULL,
    action VARCHAR(100) NOT NULL,
    entity_type VARCHAR(100),
    entity_id VARCHAR(255),
    country VARCHAR(10) NOT NULL,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Example: Configuration settings
CREATE TABLE app_settings (
    id BIGINT PRIMARY KEY,
    setting_key VARCHAR(255) NOT NULL,
    setting_value TEXT,
    country VARCHAR(10),
    language VARCHAR(10),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

## ⚙️ Configuration & Setup

### Frontend Environment (.env)
```env
VITE_API_BASE_URL=http://localhost:8080
VITE_APP_NAME=Enterprise Portal
VITE_ENABLE_DEBUG=true
```

### Backend Configuration (application.properties)
```properties
# Server Configuration
server.port=8080
spring.application.name=enterprise-regional

# H2 Development Database
spring.datasource.url=jdbc:h2:mem:testdb
spring.datasource.username=sa
spring.datasource.password=password
spring.h2.console.enabled=true

# PostgreSQL Production (uncomment when ready)
# spring.datasource.url=jdbc:postgresql://localhost:5432/enterprisedb
# spring.datasource.username=your_username
# spring.datasource.password=your_password

# JPA Configuration
spring.jpa.hibernate.ddl-auto=none
spring.sql.init.mode=always
```

### CORS Configuration
```java
@Configuration
public class CorsConfig {
    @Bean
    public CorsFilter corsFilter() {
        CorsConfiguration config = new CorsConfiguration();
        config.setAllowCredentials(true);
        // Allow all origins for development
        config.addAllowedOriginPattern("*");
        config.addAllowedOriginPattern("http://localhost:*");
        config.addAllowedOriginPattern("https://localhost:*");
        config.addAllowedOriginPattern("https://*.lovable.app");
        config.addAllowedOriginPattern("https://*.lovable.dev");
        
        config.addAllowedHeader("*");
        config.setAllowedMethods(Arrays.asList("GET", "POST", "PUT", "DELETE", "OPTIONS"));
        config.setMaxAge(3600L);

        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", config);

        return new CorsFilter(source);
    }
}
```

## 🎨 Customization Examples

### 1. Change Branding
```typescript
// Update in AppLogo.tsx
const appConfig = {
  name: 'Your Company Name',
  logo: '/your-logo.png',
  primaryColor: '#your-color'
};
```

### 2. Add New Country/Region
```typescript
// Add to country selector
const countries = [
  // existing countries...
  { code: 'ph', name: 'Philippines', flag: '🇵🇭' }
];

// Add to database
INSERT INTO users VALUES (25, 'CORP001', 'USER001', 'password123', 'PH', true, false, NOW());
```

### 3. Customize API Endpoints
```java
// Add new endpoint in Controller.java
@PostMapping("/{country}/api/v1/your-custom-endpoint")
public ResponseEntity<CustomResponse> customEndpoint(@PathVariable String country, @RequestBody CustomRequest request) {
    // Your custom implementation
}
```

## 🚀 Quick Start Instructions

### 1. Setup (5 minutes)
```bash
# Frontend
npm install && npm run dev

# Backend
cd spring-boot-backend && mvn spring-boot:run
```

### 2. Access Points
- Frontend: http://localhost:5173
- Backend API: http://localhost:8080
- Swagger UI: http://localhost:8080/swagger-ui.html
- H2 Console: http://localhost:8080/h2-console

### 3. Test Login
```
Country: Singapore (SG)
Organization: CORP001
User ID: ADMIN001
Password: password123
```

## 📋 Generated Deliverables (60-80% Production Ready)

### ✅ Fully Complete (100%)
- Database schema with mock data for all 7 countries/regions
- H2 development setup with PostgreSQL placeholder
- CORS configuration for all environments
- Swagger API documentation
- Complete project structure and organization
- Test users for all countries and scenarios

### ✅ Nearly Complete (80-90%)
- Responsive UI components matching enterprise standards
- Multi-country and multi-language support
- Authentication system with JWT tokens
- RESTful API endpoints
- Error handling and validation
- Security configurations

### ⚠️ Needs Customization (20-40% remaining)
- **Branding**: Update logos, colors, company name
- **Business Logic**: Add domain-specific features based on screenshots
- **Feature Implementation**: Implement screenshot-based components and workflows
- **API Integration**: Connect to external services
- **Database**: Configure production PostgreSQL and add business tables
- **Deployment**: Set up CI/CD pipeline
- **Testing**: Add business-specific test cases

## 🔍 Error Handling & Security

### Authentication Errors
```json
{
  "errorCode": "AUTH-001",
  "message": "Invalid credentials",
  "timestamp": "2024-01-01T00:00:00Z"
}
```

### Security Features
- JWT token authentication
- Account blocking functionality
- Password validation rules
- CORS protection
- SQL injection prevention
- Rate limiting ready

## 🧪 Testing & Quality Assurance

### Pre-loaded Test Scenarios
- Valid login for all 7 countries/regions
- Invalid credentials testing
- Blocked account handling
- New user activation flow
- Password reset workflow
- Multi-language switching
- Responsive design testing

### API Testing
- Swagger UI for endpoint testing
- Postman collection included
- Integration tests provided
- Unit tests for services

## 📚 Complete Documentation Included

- Template overview and features
- Technical architecture documentation
- API reference with examples
- Configuration and customization guide
- Quick start and setup instructions
- Testing and deployment guides
- Troubleshooting and FAQ

## 🏗️ Architecture Highlights

### Frontend Architecture
- Component-based React structure
- TypeScript for type safety
- Tailwind CSS for styling
- Shadcn/UI + Material-UI for components
- Axios for API communication
- React Router for navigation

### Backend Architecture
- Spring Boot MVC pattern
- JPA for database operations
- JWT for authentication
- Swagger for documentation
- H2 for development
- PostgreSQL for production

### Security Architecture
- Organization-based authentication
- JWT token management
- CORS configuration
- Input validation
- Error handling
- Account management

## 🎯 Business Logic Examples

### User Authentication Flow
1. User selects country/region
2. Enters organization ID, user ID, password
3. System validates credentials
4. JWT token generated and returned
5. User redirected to main application
6. Token used for subsequent API calls

### Multi-step Process Management
- Wizard-based workflows
- Progress tracking
- Step validation
- Data persistence
- Error recovery

### Content Management
- Dynamic banner content
- Country-specific configurations
- Multi-language support
- Background image management
- Announcement system

---

## 💡 How to Use This Template

**Prompt Structure for Lovable:**
```
I want to create a [APPLICATION_TYPE] similar to this enterprise template.

**Screenshots:** [Upload your desired UI screens]

**Requirements:**
- Countries/Regions: [List: US, UK, etc.]
- Languages: [EN, ES, etc.]
- User Types: [Admin, Manager, etc.]
- Features: [List specific features from screenshots]

**Technical:**
- Database: [PostgreSQL/MySQL]
- Authentication: [Method type]
- APIs: [External integrations needed]

Use the enterprise template structure for:
- Multi-country/region/language support
- Authentication system
- Responsive design
- Database setup with mock data
- Complete documentation
- CORS configuration

Generate complete application matching screenshots with 60-80% production-ready code.
```

**Template Version**: 1.0  
**Compatibility**: Lovable Platform Ready  
**Last Updated**: 2025-06-15

Start building your enterprise application today! 🏢✨
