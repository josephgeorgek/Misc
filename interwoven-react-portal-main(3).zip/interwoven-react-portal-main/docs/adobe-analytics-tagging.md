# Adobe Analytics Tagging Implementation

## Regional Bank Application - Analytics Integration

### Implementation Date: 2024-12-24
### Analytics Platform: Adobe Analytics (Experience Cloud)

## Overview

This document provides the Adobe Analytics tagging script and implementation guide for the Regional Bank application to track user interactions, page views, and business events.

## Adobe Analytics Configuration

### Data Layer Structure
```typescript
// Global data layer object
declare global {
  interface Window {
    dataLayer: any[];
    adobe: any;
    s: any; // Adobe Analytics object
  }
}
```

## Core Tagging Script

### Base Adobe Analytics Script
```html
<!-- Adobe Analytics Base Code -->
<script type="text/javascript">
  window.digitalData = {
    page: {
      pageInfo: {
        pageName: "",
        pageURL: window.location.href,
        server: "regional-bank-app",
        channel: "online-banking",
        subSection1: "",
        subSection2: "",
        language: localStorage.getItem('language') || 'en',
        country: localStorage.getItem('country') || 'sg'
      },
      category: {
        primaryCategory: "banking",
        subCategory1: "",
        subCategory2: ""
      }
    },
    user: {
      profile: [{
        profileInfo: {
          profileID: "",
          organizationId: "",
          country: "",
          language: "",
          userType: "corporate"
        }
      }]
    },
    event: []
  };

  // Adobe Analytics Configuration
  var s_code = 's_code.js';
  var s = s_gi("your-report-suite-id"); // Replace with actual Report Suite ID
  
  s.trackDownloadLinks = true;
  s.trackExternalLinks = true;
  s.trackInlineStats = true;
  s.linkDownloadFileTypes = "exe,zip,wav,mp3,mov,mpg,avi,wmv,pdf,doc,docx,xls,xlsx,ppt,pptx";
  s.linkInternalFilters = "javascript:,localhost,regional-bank";
  s.linkLeaveQueryString = false;
  s.linkTrackVars = "None";
  s.linkTrackEvents = "None";
  s.usePlugins = true;

  // Custom variables
  s.eVar1 = "";  // User ID
  s.eVar2 = "";  // Organization ID
  s.eVar3 = "";  // Country
  s.eVar4 = "";  // Language
  s.eVar5 = "";  // User Agent
  s.eVar6 = "";  // Page Type
  s.eVar7 = "";  // Error Type
  s.eVar8 = "";  // Transaction ID
  s.eVar9 = "";  // Form Name
  s.eVar10 = ""; // Button Name

  // Custom events
  s.events = "";
</script>
```

## Page Tracking Implementation

### React Component Integration
```typescript
// src/utils/analytics.ts
export class AnalyticsService {
  private static reportSuiteId = process.env.VITE_ADOBE_REPORT_SUITE_ID || 'dev-regional-bank';

  static initializeAnalytics() {
    if (typeof window !== 'undefined' && window.s) {
      // Set global properties
      window.s.server = 'regional-bank-portal';
      window.s.channel = 'online-banking';
      window.s.eVar5 = navigator.userAgent;
    }
  }

  static trackPageView(pageName: string, pageType: string, country: string, language: string) {
    if (typeof window !== 'undefined' && window.s) {
      // Update digital data layer
      window.digitalData.page.pageInfo.pageName = pageName;
      window.digitalData.page.pageInfo.country = country;
      window.digitalData.page.pageInfo.language = language;
      
      // Set Adobe Analytics variables
      window.s.pageName = pageName;
      window.s.eVar3 = country;
      window.s.eVar4 = language;
      window.s.eVar6 = pageType;
      
      // Send page view
      window.s.t();
    }
  }

  static trackUserLogin(organizationId: string, userId: string, country: string, success: boolean) {
    if (typeof window !== 'undefined' && window.s) {
      // Update user profile
      window.digitalData.user.profile[0].profileInfo.profileID = userId;
      window.digitalData.user.profile[0].profileInfo.organizationId = organizationId;
      window.digitalData.user.profile[0].profileInfo.country = country;
      
      // Set Adobe Analytics variables
      window.s.eVar1 = userId;
      window.s.eVar2 = organizationId;
      window.s.eVar3 = country;
      
      if (success) {
        window.s.events = 'event1'; // Login Success
      } else {
        window.s.events = 'event2'; // Login Failure
        window.s.eVar7 = 'authentication_failed';
      }
      
      // Send event
      window.s.tl(true, 'o', 'User Login Attempt');
    }
  }

  static trackFormInteraction(formName: string, action: string, fieldName?: string) {
    if (typeof window !== 'undefined' && window.s) {
      window.s.eVar9 = formName;
      window.s.eVar10 = fieldName || action;
      window.s.events = 'event3'; // Form Interaction
      
      window.s.tl(true, 'o', `Form ${action}: ${formName}`);
    }
  }

  static trackButtonClick(buttonName: string, location: string) {
    if (typeof window !== 'undefined' && window.s) {
      window.s.eVar10 = buttonName;
      window.s.events = 'event4'; // Button Click
      
      window.s.tl(true, 'o', `Button Click: ${buttonName} - ${location}`);
    }
  }

  static trackError(errorType: string, errorMessage: string, pageName: string) {
    if (typeof window !== 'undefined' && window.s) {
      window.s.eVar7 = errorType;
      window.s.eVar6 = pageName;
      window.s.events = 'event5'; // Error Event
      
      window.s.tl(true, 'o', `Error: ${errorType}`);
    }
  }

  static trackCountryLanguageChange(country: string, language: string) {
    if (typeof window !== 'undefined' && window.s) {
      window.s.eVar3 = country;
      window.s.eVar4 = language;
      window.s.events = 'event6'; // Preference Change
      
      window.s.tl(true, 'o', `Preference Change: ${country}-${language}`);
    }
  }
}
```

## Component-Level Tracking

### Login Component Tracking
```typescript
// src/pages/Index.tsx - Add to existing component
import { AnalyticsService } from '../utils/analytics';

const Index = () => {
  const [country, setCountry] = useState('sg');
  const [language, setLanguage] = useState('en');

  useEffect(() => {
    // Track page view
    AnalyticsService.trackPageView('Login Page', 'authentication', country, language);
  }, [country, language]);

  const handleLogin = async (credentials: any) => {
    try {
      // Track form submission
      AnalyticsService.trackFormInteraction('login-form', 'submit');
      
      const result = await AuthService.login({
        ...credentials,
        country
      });
      
      // Track successful login
      AnalyticsService.trackUserLogin(
        credentials.organizationId,
        credentials.userId,
        country,
        true
      );
      
      navigate('/dashboard');
    } catch (error) {
      // Track login failure
      AnalyticsService.trackUserLogin(
        credentials.organizationId,
        credentials.userId,
        country,
        false
      );
      
      // Track error
      AnalyticsService.trackError('login_failed', error.message, 'Login Page');
    }
  };

  const handleCountryChange = (newCountry: string) => {
    setCountry(newCountry);
    AnalyticsService.trackCountryLanguageChange(newCountry, language);
  };

  const handleLanguageToggle = () => {
    const newLanguage = language === 'en' ? 'zh' : 'en';
    setLanguage(newLanguage);
    AnalyticsService.trackCountryLanguageChange(country, newLanguage);
  };

  return (
    // ... existing JSX
  );
};
```

### Button Tracking Hook
```typescript
// src/hooks/useAnalyticsClick.ts
import { useCallback } from 'react';
import { AnalyticsService } from '../utils/analytics';

export const useAnalyticsClick = (componentName: string) => {
  const trackClick = useCallback((buttonName: string, additionalData?: any) => {
    AnalyticsService.trackButtonClick(buttonName, componentName);
    
    // Optional: Send additional custom data
    if (additionalData && window.s) {
      Object.keys(additionalData).forEach((key, index) => {
        if (index < 5) { // Limit to 5 additional props
          window.s[`prop${index + 1}`] = additionalData[key];
        }
      });
    }
  }, [componentName]);

  return trackClick;
};
```

## Event Mapping Configuration

### Business Events Mapping
```typescript
// src/config/AnalyticsConfig.ts
export const ANALYTICS_EVENTS = {
  // Authentication Events
  LOGIN_SUCCESS: 'event1',
  LOGIN_FAILURE: 'event2',
  LOGOUT: 'event11',
  PASSWORD_RESET_REQUEST: 'event12',
  USER_ACTIVATION: 'event13',
  ACCOUNT_BLOCKED: 'event14',

  // Form Events
  FORM_START: 'event3',
  FORM_COMPLETE: 'event15',
  FORM_ABANDON: 'event16',
  FIELD_ERROR: 'event17',

  // Navigation Events
  BUTTON_CLICK: 'event4',
  LINK_CLICK: 'event18',
  PAGE_SCROLL: 'event19',

  // Error Events
  ERROR_OCCURRED: 'event5',
  API_ERROR: 'event20',
  NETWORK_ERROR: 'event21',

  // Preference Events
  COUNTRY_CHANGE: 'event6',
  LANGUAGE_CHANGE: 'event22',
  THEME_CHANGE: 'event23',

  // Content Events
  HELP_DIALOG_OPEN: 'event24',
  SECURITY_NOTICE_VIEW: 'event25',
  ANNOUNCEMENT_VIEW: 'event26'
};

export const ANALYTICS_EVARS = {
  USER_ID: 'eVar1',
  ORGANIZATION_ID: 'eVar2', 
  COUNTRY: 'eVar3',
  LANGUAGE: 'eVar4',
  USER_AGENT: 'eVar5',
  PAGE_TYPE: 'eVar6',
  ERROR_TYPE: 'eVar7',
  TRANSACTION_ID: 'eVar8',
  FORM_NAME: 'eVar9',
  BUTTON_NAME: 'eVar10'
};
```

## Implementation Checklist

### Pre-Implementation
- [ ] Obtain Adobe Analytics Report Suite ID
- [ ] Configure Adobe Launch (if using)
- [ ] Set up development/staging/production environments
- [ ] Define custom events and eVars mapping
- [ ] Set up conversion goals and funnels

### Implementation Steps
- [ ] Add base Adobe Analytics script to index.html
- [ ] Implement AnalyticsService utility class
- [ ] Add page view tracking to all routes
- [ ] Implement form tracking
- [ ] Add button/link click tracking
- [ ] Implement error tracking
- [ ] Add user preference tracking
- [ ] Test in development environment

### Testing & Validation
- [ ] Use Adobe Analytics Debugger browser extension
- [ ] Verify data layer population
- [ ] Test all event triggers
- [ ] Validate cross-browser compatibility
- [ ] Performance impact assessment

### Go-Live
- [ ] Deploy to staging for final testing
- [ ] Update Report Suite ID for production
- [ ] Monitor initial data collection
- [ ] Set up real-time alerts
- [ ] Train team on Adobe Analytics dashboard

## Privacy & Compliance Considerations

### GDPR Compliance
```typescript
// src/utils/privacyConsent.ts
export class PrivacyConsent {
  static hasAnalyticsConsent(): boolean {
    return localStorage.getItem('analytics_consent') === 'true';
  }

  static setAnalyticsConsent(consent: boolean): void {
    localStorage.setItem('analytics_consent', consent.toString());
    
    if (!consent && window.s) {
      // Disable tracking
      window.s.abort = true;
    }
  }

  static shouldTrack(): boolean {
    // Only track if user has given consent
    return this.hasAnalyticsConsent();
  }
}
```

### Data Retention Policy
- **User Interaction Data**: 25 months
- **Error Logs**: 13 months  
- **Performance Metrics**: 37 months
- **Conversion Data**: 37 months

## Monitoring & Maintenance

### Key Metrics Dashboard
1. **User Engagement**
   - Page views by country/language
   - Session duration
   - Bounce rate

2. **Authentication Metrics**
   - Login success/failure rates
   - Password reset requests
   - Account blocking incidents

3. **Error Tracking**
   - Error frequency by type
   - API failure rates
   - Network connectivity issues

4. **Performance**
   - Page load times
   - Form completion rates
   - User journey abandonment points

### Regular Maintenance Tasks
- Monthly: Review and update event mappings
- Quarterly: Analyze user behavior patterns
- Semi-annually: Privacy compliance audit
- Annually: Complete analytics strategy review
