
# Generic Lovable Template Prompt

## Universal Application Generation Prompt

This prompt template can be used to generate any web application with complete frontend, backend, database, and documentation using Lovable.

### Template Structure

```markdown
I want to create a [APPLICATION_TYPE] similar to the [REFERENCE_TEMPLATE] with the following specifications:

**Application Overview:**
- Application Name: [YOUR_APP_NAME]
- Industry: [INDUSTRY_TYPE - e.g., Finance, Healthcare, E-commerce, Education]
- Target Users: [USER_TYPES - e.g., Admins, Customers, Partners]
- Primary Function: [MAIN_PURPOSE]

**Screenshots & UI Requirements:**
[Upload your screenshots or wireframes here]

**Core Features Required:**
1. [FEATURE_1] - [Description with user flow]
2. [FEATURE_2] - [Description with user flow]
3. [FEATURE_3] - [Description with user flow]
4. [Add more features as needed]

**Technical Specifications:**

**Frontend Requirements:**
- Framework: React 18 + TypeScript
- Styling: Tailwind CSS + Shadcn/UI
- Features: [Responsive design, Multi-language, Real-time updates, etc.]
- Pages: [List main pages/routes needed]
- Components: [List key components needed]

**Backend Requirements:**
- Framework: Spring Boot 3.x + Java 17+
- Database: H2 (development) + PostgreSQL (production)
- APIs: RESTful with Swagger documentation
- Features: [Authentication, CRUD operations, File upload, etc.]
- Security: [JWT, OAuth, Role-based access, etc.]

**Database Schema:**
```sql
-- Define your main entities
CREATE TABLE [entity_name] (
    id BIGINT PRIMARY KEY,
    [field_name] [DATA_TYPE],
    -- Add other fields
);
```

**Multi-Region/Language Support:**
- Countries: [List countries if applicable]
- Languages: [List languages needed]
- Localization: [Specify localization requirements]

**User Workflows:**
1. **[Workflow Name]**: [Step-by-step process]
2. **[Workflow Name]**: [Step-by-step process]
3. **[Workflow Name]**: [Step-by-step process]

**Business Logic Requirements:**
- [Business Rule 1]: [Description]
- [Business Rule 2]: [Description]
- [Business Rule 3]: [Description]

**Integration Requirements:**
- External APIs: [List any external services]
- Third-party Services: [Payment, Email, SMS, etc.]
- Data Sources: [File uploads, CSV imports, etc.]

**Security Requirements:**
- Authentication: [Method and requirements]
- Authorization: [Role-based access control]
- Data Protection: [Encryption, validation, etc.]
- Compliance: [GDPR, SOX, PCI DSS, etc.]

**Performance Requirements:**
- Concurrent Users: [Expected load]
- Response Time: [API response requirements]
- Scalability: [Growth expectations]

**Documentation Required:**
Generate complete documentation including:
1. README.md with setup instructions
2. API documentation with Swagger
3. User personas and stories
4. Technical architecture documentation
5. Database schema and data dictionary
6. Security scanning reports
7. Performance testing scripts (JMeter)
8. UI testing scripts (Selenium)
9. Health check monitoring scripts
10. Deployment and configuration guides
11. Code review and optimization reports
12. Enterprise architecture diagrams (C4 Model)
13. Mock data generation scripts
14. Adobe Analytics implementation
15. Observability and logging setup

**Deliverables Expected:**
✅ Complete React frontend application (60-80% production ready)
✅ Spring Boot backend with REST APIs
✅ H2 database with sample data + PostgreSQL configuration
✅ Comprehensive documentation (15+ documents)
✅ Testing scripts and security analysis
✅ Deployment configuration
✅ Performance optimization recommendations
✅ Future enhancement roadmap

**Success Criteria:**
- Application loads and functions correctly
- All user workflows are operational
- APIs respond within acceptable timeframes
- Security measures are implemented
- Documentation is comprehensive and accurate
- Code follows best practices and is maintainable

Use the existing banking template architecture as reference for:
- Multi-country/language support patterns
- Authentication and security implementation
- Dynamic content management
- Responsive UI design principles
- Complete documentation structure
- Testing and deployment practices

Generate a complete, production-ready application with all requested features and comprehensive documentation.
```

## Example Usage Scenarios

### E-commerce Platform
```markdown
I want to create an E-commerce Platform similar to the banking template with:
- Multi-vendor support
- Product catalog management
- Shopping cart and checkout
- Order management system
- User authentication and profiles
- Payment gateway integration
- Admin dashboard
- Multi-language support (EN, ES, FR)
```

### Healthcare Management System
```markdown
I want to create a Healthcare Management System similar to the banking template with:
- Patient registration and profiles
- Appointment scheduling
- Medical records management
- Doctor/staff management
- Prescription management
- Insurance integration
- Reporting dashboard
- HIPAA compliance features
```

### Project Management Tool
```markdown
I want to create a Project Management Tool similar to the banking template with:
- Project creation and management
- Task assignment and tracking
- Team collaboration features
- Time tracking and reports
- File sharing and storage
- Kanban boards and Gantt charts
- Multi-tenant architecture
- Real-time notifications
```

### Educational Platform
```markdown
I want to create an Educational Platform similar to the banking template with:
- Course management system
- Student enrollment and progress tracking
- Assignment and grading system
- Video content delivery
- Discussion forums
- Certification management
- Multi-language support
- Mobile-responsive design
```

## Customization Guidelines

### For Different Industries
- **Finance**: Focus on security, compliance, multi-currency support
- **Healthcare**: Emphasize privacy, HIPAA compliance, appointment scheduling
- **E-commerce**: Priority on payment processing, inventory management, shipping
- **Education**: Highlight content delivery, progress tracking, collaboration

### For Different Scales
- **Startup/MVP**: Basic features, simple architecture, rapid deployment
- **Enterprise**: Complex workflows, integration requirements, scalability
- **Mid-market**: Balanced approach with growth considerations

### For Different Regions
- **Global**: Multi-language, multi-currency, timezone handling
- **Regional**: Local compliance, specific integrations, cultural considerations
- **Local**: Simple deployment, basic features, cost-effective

## Template Validation Checklist

Before submitting your prompt, ensure:
- [ ] Clear application purpose and target users defined
- [ ] Screenshots or wireframes provided (if available)
- [ ] Core features with user flows specified
- [ ] Technical requirements clearly stated
- [ ] Database schema outlined
- [ ] Security requirements defined
- [ ] Documentation needs specified
- [ ] Success criteria established

## Expected Delivery Timeline
- **Initial Setup**: 30 minutes (basic structure)
- **Core Features**: 2-4 hours (depending on complexity)
- **Documentation**: 1-2 hours (comprehensive set)
- **Testing & Optimization**: 1-2 hours (scripts and analysis)
- **Total**: 4-8 hours for complete application with documentation

## Support and Enhancement
After initial delivery, you can request:
- Additional features or modifications
- Performance optimizations
- Security enhancements
- UI/UX improvements
- Integration with external services
- Deployment assistance
- Documentation updates

This template ensures you get a complete, production-ready application with comprehensive documentation, following the same high standards as the banking template.
