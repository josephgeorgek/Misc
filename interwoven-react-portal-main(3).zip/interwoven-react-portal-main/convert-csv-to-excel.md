# Converting CSV to Excel for Test Data

## Instructions to Create testdata.xlsx

Since the test framework expects an Excel file (`testdata.xlsx`), follow these steps to convert the provided CSV data:

### Option 1: Using Microsoft Excel
1. Open Microsoft Excel
2. Go to File → Open
3. Select the `testdata.csv` file
4. Choose "Delimited" and "Comma" as separator
5. Create separate sheets for each section:
   - **ValidLogin** sheet with valid login test data
   - **InvalidLogin** sheet with invalid login test data  
   - **Countries** sheet with country configuration
   - **PreApprovedLoans** sheet with loan-specific test data
6. Save as `testdata.xlsx` in `src/test/resources/` directory

### Option 2: Using Online Converter
1. Use any online CSV to Excel converter
2. Upload the `testdata.csv` file
3. Download the converted Excel file
4. Rename to `testdata.xlsx`
5. Place in `src/test/resources/` directory

### Option 3: Using Apache POI (Programmatic)
Create a Java utility to convert CSV to Excel:

```java
public class CSVToExcelConverter {
    public static void convertCSVToExcel(String csvFile, String excelFile) {
        try (BufferedReader br = new BufferedReader(new FileReader(csvFile));
             XSSFWorkbook workbook = new XSSFWorkbook()) {
            
            XSSFSheet validLoginSheet = workbook.createSheet("ValidLogin");
            XSSFSheet invalidLoginSheet = workbook.createSheet("InvalidLogin");
            XSSFSheet countriesSheet = workbook.createSheet("Countries");
            XSSFSheet preApprovedLoansSheet = workbook.createSheet("PreApprovedLoans");
            
            // Parse CSV and populate sheets accordingly
            // Implementation details would go here
            
            FileOutputStream outputStream = new FileOutputStream(excelFile);
            workbook.write(outputStream);
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
```

## Excel Sheet Structure

### ValidLogin Sheet
| Column A | Column B | Column C | Column D | Column E |
|----------|----------|----------|----------|----------|
| Country  | OrgId    | UserId   | Password | ExpectedResult |
| SG       | ACME001  | JOHNDOE  | password123 | Success |

### InvalidLogin Sheet  
| Column A | Column B | Column C | Column D | Column E |
|----------|----------|----------|----------|----------|
| Country  | OrgId    | UserId   | Password | ExpectedError |
| SG       | INVALID  | JOHNDOE  | password123 | Invalid organization |

### Countries Sheet
| Column A | Column B | Column C | Column D | Column E |
|----------|----------|----------|----------|----------|
| CountryCode | CountryName | Language | Currency | Timezone |
| SG       | Singapore | en       | SGD      | Asia/Singapore |

### PreApprovedLoans Sheet
| Column A | Column B | Column C | Column D | Column E | Column F | Column G | Column H |
|----------|----------|----------|----------|----------|----------|----------|----------|
| OrgId    | UserId   | Password | Country  | HasPreApprovedLoan | AFLOfferStatus | CIFNumber | LoanAmount |
| CORP-123 | JOHN-130 | pass@123 | Singapore | Yes | ELIGIBLE | CIF001 | 50000 |

## Final File Location
Place the completed `testdata.xlsx` file in:
```
spring-boot-backend/src/test/resources/testdata.xlsx
```