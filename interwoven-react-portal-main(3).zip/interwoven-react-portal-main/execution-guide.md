# Selenium UI Testing Execution Guide

## Prerequisites

### 1. Install Dependencies
```bash
# Navigate to spring-boot-backend directory
cd spring-boot-backend

# Add Selenium dependencies to pom.xml (if not already added)
# The dependencies are already documented in the selenium guide
```

### 2. Setup Test Structure
Create the following directory structure in your spring-boot-backend:
```
spring-boot-backend/
├── src/test/java/com/bank/regional/
│   ├── tests/
│   │   ├── base/BaseTest.java
│   │   ├── functional/LoginFunctionalityTests.java
│   │   ├── security/PasswordValidationTests.java
│   │   └── e2e/CompleteUserJourneyTests.java
│   ├── pages/
│   │   ├── LoginPage.java
│   │   └── DashboardPage.java
│   └── utils/TestDataProvider.java
├── src/test/resources/
│   ├── test.properties
│   ├── testdata.xlsx
│   └── features/
└── testng.xml
```

## Execution Steps

### Step 1: Start the Application
```bash
# Start the React frontend
npm run dev
# Application will run on http://localhost:8080

# Start the Spring Boot backend (in another terminal)
cd spring-boot-backend
mvn spring-boot:run
# Backend will run on http://localhost:8081
```

### Step 2: Run Tests via Maven
```bash
# Run all tests
mvn test

# Run specific test suite
mvn test -Dtest=LoginFunctionalityTests

# Run with specific browser
mvn test -Dbrowser=chrome

# Run with TestNG XML
mvn test -DsuiteXmlFile=testng.xml
```

### Step 3: Run Tests via TestNG
```bash
# Run with TestNG directly
java -cp "target/test-classes:target/classes:target/lib/*" org.testng.TestNG testng.xml

# Run specific test class
java -cp "target/test-classes:target/classes:target/lib/*" org.testng.TestNG -testclass com.bank.regional.tests.functional.LoginFunctionalityTests
```

### Step 4: Run Feature Tests (BDD Style)
```bash
# If using Cucumber (optional enhancement)
mvn test -Dcucumber.options="--tags @login"
mvn test -Dcucumber.options="--tags @positive"
mvn test -Dcucumber.options="--tags @smoke"
```

## Test Execution Options

### Browser Selection
```bash
# Chrome (default)
mvn test -Dbrowser=chrome

# Firefox
mvn test -Dbrowser=firefox

# Edge
mvn test -Dbrowser=edge
```

### Environment Selection
```bash
# Development (default)
mvn test -Denvironment=dev

# Staging
mvn test -Denvironment=staging -Dbase.url=https://staging.regionalbank.com
```

### Parallel Execution
```bash
# Run tests in parallel
mvn test -Dparallel=methods -DthreadPoolSize=3
```

## Test Reports

### ExtentReports
- Location: `test-reports/ExtentReport.html`
- View in browser after test execution

### TestNG Reports
- Location: `target/surefire-reports/`
- HTML report: `target/surefire-reports/index.html`

### Screenshots
- Failure screenshots: `test-reports/screenshots/`
- Automatically captured on test failures

## Debugging

### Debug Mode
```bash
# Run with debug output
mvn test -X

# Run single test with debugging
mvn test -Dtest=LoginFunctionalityTests#testSuccessfulLogin -X
```

### Headless Mode
```bash
# Run tests headless (for CI/CD)
mvn test -Dheadless=true
```

## CI/CD Integration

### Jenkins Pipeline Example
```groovy
pipeline {
    agent any
    stages {
        stage('Test') {
            steps {
                sh 'mvn test -Dbrowser=chrome -Dheadless=true'
            }
            post {
                always {
                    publishHTML([
                        allowMissing: false,
                        alwaysLinkToLastBuild: true,
                        keepAll: true,
                        reportDir: 'test-reports',
                        reportFiles: 'ExtentReport.html',
                        reportName: 'Selenium Test Report'
                    ])
                }
            }
        }
    }
}
```

### GitHub Actions Example
```yaml
name: UI Tests
on: [push, pull_request]
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - name: Set up JDK 11
        uses: actions/setup-java@v2
        with:
          java-version: '11'
          distribution: 'adopt'
      - name: Run tests
        run: mvn test -Dbrowser=chrome -Dheadless=true
      - name: Upload test reports
        uses: actions/upload-artifact@v2
        with:
          name: test-reports
          path: test-reports/
```

## Troubleshooting

### Common Issues
1. **WebDriver not found**: Ensure WebDriverManager is properly configured
2. **Element not found**: Check page load timing and waits
3. **Browser launch failure**: Verify browser installation and permissions
4. **Port conflicts**: Ensure application is running on expected ports

### Logs
- Selenium logs: `target/selenium.log`
- Application logs: Check Spring Boot console output
- Browser logs: Captured in test reports