
#!/bin/bash

# Start Bitbucket CORS Proxy Server
echo "🚀 Starting Bitbucket CORS Proxy Server..."

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "❌ Node.js is not installed. Please install Node.js first."
    exit 1
fi

# Check if npm is installed
if ! command -v npm &> /dev/null; then
    echo "❌ npm is not installed. Please install npm first."
    exit 1
fi

# Install dependencies if node_modules doesn't exist
if [ ! -d "node_modules" ]; then
    echo "📦 Installing dependencies..."
    npm install --package-lock-only --no-package-lock --silent
    npm install express http-proxy-middleware cors
fi

# Start the proxy server
echo "🌐 Starting proxy server on port 3001..."
node proxy-server.js
