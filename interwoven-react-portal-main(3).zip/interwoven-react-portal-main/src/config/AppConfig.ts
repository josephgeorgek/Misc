interface BackgroundConfig {
  loginBackgroundUrl: string;
  fallbackBackgroundUrl: string;
}

interface SecurityNoticeConfig {
  announcementUrl: string;
  fallbackNotice: {
    en: string;
    zh: string;
  };
}

interface NeedHelpConfig {
  contentUrl: string;
}

class AppConfig {
  private static backgroundConfig: BackgroundConfig = {
    loginBackgroundUrl: '/bitbucket/projects/OCMFE/repos/mfe-dbr-tasks/raw/public/bank-up/background.png',
    fallbackBackgroundUrl: '/lovable-uploads/6fffa759-a2a4-48dc-9970-6f351d662bb6.png'
  };

  private static securityNoticeConfig: SecurityNoticeConfig = {
    announcementUrl: '/bitbucket/projects/OCMFE/repos/mfe-dbr-tasks/raw/public/announcement.txt',
    fallbackNotice: {
      en: 'Security advisory: Stay vigilant against fraudulent activities. Verify all transactions and contact us immediately if you notice any suspicious activity.',
      zh: '安全提醒：保持警惕，防范欺诈活动。验证所有交易，如发现任何可疑活动请立即联系我们。'
    }
  };

  private static needHelpConfig: NeedHelpConfig = {
    contentUrl: '/bitbucket/projects/OCMFE/repos/mfe-dbr-tasks/raw/public/help-content.txt'
  };

  static getBackgroundConfig(): BackgroundConfig {
    return this.backgroundConfig;
  }

  static getSecurityNoticeConfig(): SecurityNoticeConfig {
    return this.securityNoticeConfig;
  }

  static getNeedHelpConfig(): NeedHelpConfig {
    return this.needHelpConfig;
  }

  static getLoginBackgroundUrl(): string {
    return this.backgroundConfig.loginBackgroundUrl;
  }

  static getFallbackBackgroundUrl(): string {
    return this.backgroundConfig.fallbackBackgroundUrl;
  }

  static getNeedHelpContentUrl(): string {
    return this.needHelpConfig.contentUrl;
  }
}

export default AppConfig;
