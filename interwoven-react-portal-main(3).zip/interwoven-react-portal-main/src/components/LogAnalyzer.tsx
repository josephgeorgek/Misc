
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Upload, BarChart3, Shield, AlertTriangle, TrendingUp, Clock } from 'lucide-react';
import LogAnalysisService, { LogEntry, AnalysisResult } from '../services/LogAnalysisService';

const LogAnalyzer = () => {
  const [rawLogs, setRawLogs] = useState('');
  const [analysis, setAnalysis] = useState<AnalysisResult | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const logAnalysisService = LogAnalysisService.getInstance();

  const handleAnalyzeLogs = async () => {
    if (!rawLogs.trim()) {
      setError('Please provide log data to analyze');
      return;
    }

    setIsAnalyzing(true);
    setError(null);

    try {
      // Parse logs (simplified parsing - in real implementation, this would be more sophisticated)
      const parsedLogs = parseRawLogs(rawLogs);
      
      if (parsedLogs.length === 0) {
        throw new Error('No valid log entries found. Please check the log format.');
      }

      const result = await logAnalysisService.analyzeLogsInRealTime(parsedLogs);
      setAnalysis(result);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to analyze logs');
    } finally {
      setIsAnalyzing(false);
    }
  };

  const parseRawLogs = (logs: string): LogEntry[] => {
    const lines = logs.split('\n').filter(line => line.trim());
    const parsedLogs: LogEntry[] = [];

    lines.forEach((line, index) => {
      try {
        // Try to parse as JSON first
        if (line.trim().startsWith('{')) {
          const jsonLog = JSON.parse(line);
          parsedLogs.push({
            timestamp: jsonLog.timestamp || new Date().toISOString(),
            level: jsonLog.level || 'INFO',
            service: jsonLog.service || 'unknown',
            message: jsonLog.message || line,
            traceId: jsonLog.traceId,
            userId: jsonLog.userId,
            responseTime: jsonLog.responseTime,
            statusCode: jsonLog.statusCode,
            ip: jsonLog.ip,
            country: jsonLog.country,
            metadata: jsonLog
          });
        } else {
          // Parse structured log format
          const logPattern = /(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}.\d{3}Z)\s+(INFO|DEBUG|WARN|ERROR|CRITICAL)\s+\[([^\]]+)\](?:\s+\[trace-id:([^\]]+)\])?\s+(.+)/;
          const match = line.match(logPattern);
          
          if (match) {
            const [, timestamp, level, service, traceId, message] = match;
            
            // Extract additional info from message
            const ipMatch = message.match(/IP:\s*([0-9.]+)/);
            const countryMatch = message.match(/Country:\s*([A-Z]{2})/);
            const userMatch = message.match(/user:([^\s\]]+)/);
            const responseTimeMatch = message.match(/Duration:\s*(\d+)ms/);
            const statusMatch = message.match(/Status:\s*(\d+)/);

            parsedLogs.push({
              timestamp,
              level: level as LogEntry['level'],
              service: service.trim(),
              traceId,
              message: message.trim(),
              ip: ipMatch ? ipMatch[1] : undefined,
              country: countryMatch ? countryMatch[1] : undefined,
              userId: userMatch ? userMatch[1] : undefined,
              responseTime: responseTimeMatch ? parseInt(responseTimeMatch[1]) : undefined,
              statusCode: statusMatch ? parseInt(statusMatch[1]) : undefined
            });
          } else {
            // Fallback for unstructured logs
            parsedLogs.push({
              timestamp: new Date().toISOString(),
              level: 'INFO',
              service: 'unknown',
              message: line.trim()
            });
          }
        }
      } catch (err) {
        console.warn(`Failed to parse log line ${index + 1}:`, line);
      }
    });

    return parsedLogs;
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'CRITICAL': return 'destructive';
      case 'HIGH': return 'destructive';
      case 'MEDIUM': return 'secondary';
      case 'LOW': return 'outline';
      default: return 'outline';
    }
  };

  const getHealthColor = (score: number) => {
    if (score >= 90) return 'text-green-600';
    if (score >= 70) return 'text-yellow-600';
    return 'text-red-600';
  };

  const loadSampleLogs = () => {
    const sampleLogs = `2024-12-26T08:15:23.456Z INFO  [auth-service] [trace-id:abc123] [user:ACME001-JOHNDOE] Authentication request received - Country: SG, IP: 203.116.43.15
2024-12-26T08:15:23.515Z INFO  [auth-service] [trace-id:abc123] Login successful - Duration: 59ms, Method: PASSWORD
2024-12-26T08:16:45.123Z WARN  [auth-service] [trace-id:def456] [user:BLOCKED001-TESTUSER] Authentication attempt for blocked user - IP: 192.168.1.100
2024-12-26T08:17:12.789Z ERROR [auth-service] [trace-id:ghi789] Authentication failed - Invalid credentials - User: CORP002-INVALID, IP: 10.0.1.50
2024-12-26T08:20:15.234Z INFO  [content-service] [trace-id:jkl012] Content request received - Country: MY, Language: EN, Type: BANNER
2024-12-26T08:20:15.320Z INFO  [content-service] [trace-id:jkl012] Content served successfully - Size: 2.1KB
2024-12-26T08:22:45.123Z ERROR [content-service] [trace-id:pqr678] External content fetch failed - URL: https://bitbucket.ocbc.com/announcement.txt
2024-12-26T08:25:10.123Z INFO  [api-gateway] [trace-id:stu901] Request received - Method: POST, Path: /sg/customer-security-corp/v1/orguserid-login, IP: 203.116.43.15
2024-12-26T08:25:10.226Z INFO  [api-gateway] [trace-id:stu901] Request completed - Total Duration: 103ms, Status: 200
2024-12-26T08:26:30.456Z WARN  [api-gateway] [trace-id:vwx234] Rate limit exceeded - IP: 192.168.1.200, Requests: 101/100 per minute
2024-12-26T08:30:00.123Z INFO  [database] Connection pool stats - Active: 8/20, Idle: 12/20, Wait: 0
2024-12-26T08:35:45.567Z WARN  [database] Slow query detected - Duration: 2.5s, Query: SELECT * FROM audit_events WHERE created_at BETWEEN...
2024-12-26T08:40:12.890Z ERROR [database] Connection timeout - Pool exhausted, waiting connections: 5
2024-12-26T08:45:00.123Z INFO  [metrics] Application metrics - CPU: 65%, Memory: 1.2GB/2GB, Heap: 800MB/1GB
2024-12-26T08:50:30.456Z WARN  [metrics] High memory usage detected - Current: 1.8GB/2GB (90%)
2024-12-26T08:55:15.789Z ALERT [metrics] Response time threshold exceeded - P95: 450ms (Threshold: 200ms)`;
    
    setRawLogs(sampleLogs);
  };

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center gap-2 mb-6">
        <BarChart3 className="h-6 w-6 text-blue-600" />
        <h1 className="text-2xl font-bold">AI-Powered Log Analysis</h1>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Upload className="h-5 w-5" />
            Log Input
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-2 mb-4">
            <Button 
              variant="outline" 
              onClick={loadSampleLogs}
              className="flex items-center gap-2"
            >
              Load Sample Logs
            </Button>
          </div>
          
          <Textarea
            placeholder="Paste your log data here... Supports JSON format and structured logs"
            value={rawLogs}
            onChange={(e) => setRawLogs(e.target.value)}
            className="min-h-[200px] font-mono text-sm"
          />

          {error && (
            <Alert>
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          <Button 
            onClick={handleAnalyzeLogs}
            disabled={isAnalyzing || !rawLogs.trim()}
            className="w-full"
          >
            {isAnalyzing ? 'Analyzing Logs...' : 'Analyze Logs with AI'}
          </Button>
        </CardContent>
      </Card>

      {analysis && (
        <Tabs defaultValue="summary" className="space-y-4">
          <TabsList className="grid w-full grid-cols-6">
            <TabsTrigger value="summary">Summary</TabsTrigger>
            <TabsTrigger value="issues">Issues</TabsTrigger>
            <TabsTrigger value="performance">Performance</TabsTrigger>
            <TabsTrigger value="anomalies">Anomalies</TabsTrigger>
            <TabsTrigger value="predictions">Predictions</TabsTrigger>
            <TabsTrigger value="security">Security</TabsTrigger>
          </TabsList>

          <TabsContent value="summary">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="h-5 w-5" />
                  Executive Summary
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold">{analysis.summary.totalEntries.toLocaleString()}</div>
                    <div className="text-sm text-gray-600">Log Entries</div>
                  </div>
                  <div className="text-center">
                    <div className={`text-2xl font-bold ${getHealthColor(analysis.summary.healthScore)}`}>
                      {analysis.summary.healthScore}
                    </div>
                    <div className="text-sm text-gray-600">Health Score</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold">{analysis.summary.confidence}%</div>
                    <div className="text-sm text-gray-600">AI Confidence</div>
                  </div>
                  <div className="text-center">
                    <Badge variant={analysis.summary.overallStatus === 'HEALTHY' ? 'default' : 'destructive'}>
                      {analysis.summary.overallStatus}
                    </Badge>
                  </div>
                </div>
                
                <div>
                  <div className="text-sm text-gray-600 mb-2">Health Score</div>
                  <Progress value={analysis.summary.healthScore} className="h-2" />
                </div>

                <div className="text-sm text-gray-600">
                  <strong>Analysis Period:</strong> {new Date(analysis.summary.timeRange.start).toLocaleString()} - {new Date(analysis.summary.timeRange.end).toLocaleString()}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="issues">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5" />
                  Critical Issues ({analysis.criticalIssues.length})
                </CardTitle>
              </CardHeader>
              <CardContent>
                {analysis.criticalIssues.length === 0 ? (
                  <div className="text-center text-gray-500 py-8">
                    No critical issues detected
                  </div>
                ) : (
                  <div className="space-y-4">
                    {analysis.criticalIssues.map((issue, index) => (
                      <div key={index} className="border rounded-lg p-4">
                        <div className="flex items-center gap-2 mb-2">
                          <Badge variant={getSeverityColor(issue.severity)}>
                            {issue.severity}
                          </Badge>
                          <h3 className="font-medium">{issue.type.replace(/_/g, ' ')}</h3>
                        </div>
                        <p className="text-sm text-gray-600 mb-2">{issue.description}</p>
                        <div className="grid grid-cols-2 gap-4 text-sm">
                          <div>
                            <strong>Occurrences:</strong> {issue.occurrences}
                          </div>
                          <div>
                            <strong>Affected Services:</strong> {issue.affectedServices.join(', ')}
                          </div>
                        </div>
                        {issue.rootCause && (
                          <div className="mt-2 text-sm">
                            <strong>Root Cause:</strong> {issue.rootCause}
                          </div>
                        )}
                        <div className="mt-2 text-sm bg-blue-50 p-2 rounded">
                          <strong>Recommendation:</strong> {issue.recommendation}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="performance">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5" />
                  Performance Metrics
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                  <div className="text-center">
                    <div className="text-2xl font-bold">{Math.round(analysis.performanceMetrics.throughput)}</div>
                    <div className="text-sm text-gray-600">Requests/Min</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold">{analysis.performanceMetrics.errorRate.toFixed(2)}%</div>
                    <div className="text-sm text-gray-600">Error Rate</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold">{analysis.performanceMetrics.availability.toFixed(1)}%</div>
                    <div className="text-sm text-gray-600">Availability</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold">{analysis.performanceMetrics.responseTime.p95}ms</div>
                    <div className="text-sm text-gray-600">P95 Response</div>
                  </div>
                </div>

                <div className="mt-6">
                  <h4 className="font-medium mb-3">Response Time Distribution</h4>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>P50 (Median)</span>
                      <span>{analysis.performanceMetrics.responseTime.p50}ms</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>P95</span>
                      <span>{analysis.performanceMetrics.responseTime.p95}ms</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>P99</span>
                      <span>{analysis.performanceMetrics.responseTime.p99}ms</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="anomalies">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5" />
                  Detected Anomalies
                </CardTitle>
              </CardHeader>
              <CardContent>
                {analysis.anomalies.length === 0 ? (
                  <div className="text-center text-gray-500 py-8">
                    No anomalies detected
                  </div>
                ) : (
                  <div className="space-y-3">
                    {analysis.anomalies.map((anomaly, index) => (
                      <div key={index} className="border rounded-lg p-3">
                        <div className="flex items-center gap-2 mb-2">
                          <Badge variant={anomaly.impact === 'HIGH' ? 'destructive' : 'secondary'}>
                            {anomaly.impact} Impact
                          </Badge>
                          <span className="font-medium">{anomaly.type.replace(/_/g, ' ')}</span>
                          <span className="text-sm text-gray-500">
                            ({Math.round(anomaly.confidence * 100)}% confidence)
                          </span>
                        </div>
                        <p className="text-sm text-gray-600">{anomaly.description}</p>
                        <div className="text-xs text-gray-500 mt-1">
                          Timeframe: {anomaly.timeframe}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="predictions">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Clock className="h-5 w-5" />
                  Predictive Analysis
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <h4 className="font-medium mb-3">Next Hour Forecast</h4>
                  <div className="bg-blue-50 p-4 rounded-lg">
                    <div className="mb-2">
                      <strong>Expected Load:</strong> {analysis.predictions.nextHourForecast.expectedLoad} requests
                    </div>
                    <div className="mb-2">
                      <strong>Risk Factors:</strong>
                      <ul className="list-disc list-inside ml-4 text-sm">
                        {analysis.predictions.nextHourForecast.riskFactors.map((risk, index) => (
                          <li key={index}>{risk}</li>
                        ))}
                      </ul>
                    </div>
                    <div>
                      <strong>Recommended Actions:</strong>
                      <ul className="list-disc list-inside ml-4 text-sm">
                        {analysis.predictions.nextHourForecast.recommendedActions.map((action, index) => (
                          <li key={index}>{action}</li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </div>

                <div>
                  <h4 className="font-medium mb-3">Incident Predictions</h4>
                  <div className="space-y-3">
                    {analysis.predictions.incidents.map((incident, index) => (
                      <div key={index} className="border rounded-lg p-3">
                        <div className="flex items-center gap-2 mb-2">
                          <span className="font-medium">{incident.type}</span>
                          <Badge variant="outline">
                            {Math.round(incident.probability * 100)}% probability
                          </Badge>
                        </div>
                        <div className="text-sm text-gray-600 mb-2">
                          <strong>Timeframe:</strong> {incident.timeframe}
                        </div>
                        <div className="text-sm">
                          <strong>Preventive Actions:</strong>
                          <ul className="list-disc list-inside ml-4">
                            {incident.preventiveActions.map((action, idx) => (
                              <li key={idx}>{action}</li>
                            ))}
                          </ul>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="security">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Shield className="h-5 w-5" />
                  Security Analysis
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center gap-4">
                  <div>
                    <strong>Threat Level:</strong>
                  </div>
                  <Badge variant={
                    analysis.securityAnalysis.threatLevel === 'CRITICAL' ? 'destructive' :
                    analysis.securityAnalysis.threatLevel === 'HIGH' ? 'destructive' :
                    analysis.securityAnalysis.threatLevel === 'MEDIUM' ? 'secondary' : 'outline'
                  }>
                    {analysis.securityAnalysis.threatLevel}
                  </Badge>
                </div>

                {analysis.securityAnalysis.suspiciousActivities.length > 0 && (
                  <div>
                    <h4 className="font-medium mb-3">Suspicious Activities</h4>
                    <div className="space-y-3">
                      {analysis.securityAnalysis.suspiciousActivities.map((activity, index) => (
                        <div key={index} className="border rounded-lg p-3">
                          <div className="flex items-center gap-2 mb-2">
                            <span className="font-medium">{activity.type.replace(/_/g, ' ')}</span>
                            <span className="text-sm text-gray-500">
                              ({Math.round(activity.confidence * 100)}% confidence)
                            </span>
                          </div>
                          <p className="text-sm text-gray-600 mb-1">{activity.description}</p>
                          <div className="text-xs text-gray-500">Source: {activity.source}</div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                <div>
                  <h4 className="font-medium mb-3">Security Recommendations</h4>
                  <ul className="list-disc list-inside space-y-1 text-sm">
                    {analysis.securityAnalysis.recommendations.map((rec, index) => (
                      <li key={index}>{rec}</li>
                    ))}
                  </ul>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      )}
    </div>
  );
};

export default LogAnalyzer;
