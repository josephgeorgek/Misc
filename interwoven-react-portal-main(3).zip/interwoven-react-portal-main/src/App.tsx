
import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { NuqsAdapter } from "nuqs/adapters/react-router";
import Index from "./pages/Index";
import Dashboard from "./pages/Dashboard";
import BackofficeLogin from "./pages/BackofficeLogin";
import BackofficeDashboard from "./pages/BackofficeDashboard";
import NotFound from "./pages/NotFound";

// Force GitHub sync update - latest changes should now be reflected
const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <NuqsAdapter>
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<Index />} />
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/backoffice-login" element={<BackofficeLogin />} />
            <Route path="/backoffice-dashboard" element={<BackofficeDashboard />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </NuqsAdapter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
