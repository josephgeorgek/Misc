
import React, { useState, useEffect } from 'react';
import { 
  Users, 
  Activity, 
  Shield, 
  AlertTriangle, 
  TrendingUp, 
  TrendingDown,
  Globe,
  Clock,
  BarChart3,
  PieChart,
  LogOut,
  Eye
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useNavigate } from 'react-router-dom';

const BackofficeDashboard = () => {
  const navigate = useNavigate();
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const handleLogout = () => {
    localStorage.removeItem('adminToken');
    localStorage.removeItem('adminSession');
    navigate('/backoffice-login');
  };

  // Mock data for demonstration
  const loginInsights = {
    totalLogins: 2847,
    successfulLogins: 2623,
    failedLogins: 224,
    successRate: 92.1,
    activeUsers: 1456,
    newUsers: 89,
    suspiciousActivity: 12,
    topCountries: [
      { country: 'Singapore', count: 1024, flag: '🇸🇬' },
      { country: 'Malaysia', count: 789, flag: '🇲🇾' },
      { country: 'Hong Kong', count: 567, flag: '🇭🇰' },
      { country: 'Indonesia', count: 234, flag: '🇮🇩' },
      { country: 'Thailand', count: 156, flag: '🇹🇭' }
    ],
    recentActivity: [
      { time: '14:32', user: 'ACME001-JOHNDOE', country: 'SG', status: 'success' },
      { time: '14:31', user: 'CORP002-JANE', country: 'MY', status: 'failed' },
      { time: '14:30', user: 'TECH003-MIKE', country: 'HK', status: 'success' },
      { time: '14:29', user: 'BANK004-SARAH', country: 'ID', status: 'success' },
      { time: '14:28', user: 'INVEST005-DAVID', country: 'TH', status: 'blocked' }
    ],
    hourlyTrends: [
      { hour: '09:00', logins: 145 },
      { hour: '10:00', logins: 189 },
      { hour: '11:00', logins: 234 },
      { hour: '12:00', logins: 198 },
      { hour: '13:00', logins: 167 },
      { hour: '14:00', logins: 223 },
      { hour: '15:00', logins: 156 }
    ]
  };

  return (
    <div className="min-h-screen bg-slate-900 text-white">
      {/* Header */}
      <header className="bg-slate-800 border-b border-slate-700 px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Shield className="h-8 w-8 text-blue-400" />
            <div>
              <h1 className="text-xl font-bold">Admin Portal</h1>
              <p className="text-sm text-slate-400">Login Insights Dashboard</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="text-right">
              <p className="text-sm text-slate-300">{currentTime.toLocaleTimeString()}</p>
              <p className="text-xs text-slate-400">{currentTime.toLocaleDateString()}</p>
            </div>
            <Button
              onClick={handleLogout}
              variant="ghost"
              size="sm"
              className="text-slate-400 hover:text-white"
            >
              <LogOut className="h-4 w-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </header>

      <div className="p-6 space-y-6">
        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-slate-300">Total Logins</CardTitle>
              <Users className="h-4 w-4 text-blue-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">{loginInsights.totalLogins.toLocaleString()}</div>
              <p className="text-xs text-green-400 flex items-center mt-1">
                <TrendingUp className="h-3 w-3 mr-1" />
                +12% from yesterday
              </p>
            </CardContent>
          </Card>

          <Card className="bg-slate-800 border-slate-700">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-slate-300">Success Rate</CardTitle>
              <Activity className="h-4 w-4 text-green-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">{loginInsights.successRate}%</div>
              <p className="text-xs text-green-400 flex items-center mt-1">
                <TrendingUp className="h-3 w-3 mr-1" />
                +2.1% from last week
              </p>
            </CardContent>
          </Card>

          <Card className="bg-slate-800 border-slate-700">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-slate-300">Failed Logins</CardTitle>
              <AlertTriangle className="h-4 w-4 text-red-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">{loginInsights.failedLogins}</div>
              <p className="text-xs text-red-400 flex items-center mt-1">
                <TrendingDown className="h-3 w-3 mr-1" />
                -5% from yesterday
              </p>
            </CardContent>
          </Card>

          <Card className="bg-slate-800 border-slate-700">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-slate-300">Active Users</CardTitle>
              <Eye className="h-4 w-4 text-purple-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">{loginInsights.activeUsers.toLocaleString()}</div>
              <p className="text-xs text-purple-400 flex items-center mt-1">
                <TrendingUp className="h-3 w-3 mr-1" />
                +8% from last hour
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Charts and Tables */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Top Countries */}
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Globe className="h-5 w-5" />
                Login by Country
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {loginInsights.topCountries.map((country, index) => (
                  <div key={country.country} className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <span className="text-lg">{country.flag}</span>
                      <span className="text-slate-300">{country.country}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-20 bg-slate-700 rounded-full h-2">
                        <div 
                          className="bg-blue-500 h-2 rounded-full" 
                          style={{ width: `${(country.count / loginInsights.topCountries[0].count) * 100}%` }}
                        />
                      </div>
                      <span className="text-white font-medium w-12 text-right">{country.count}</span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Recent Activity */}
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Clock className="h-5 w-5" />
                Recent Login Activity
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {loginInsights.recentActivity.map((activity, index) => (
                  <div key={index} className="flex items-center justify-between p-2 rounded bg-slate-700">
                    <div className="flex items-center gap-3">
                      <span className="text-xs text-slate-400 w-12">{activity.time}</span>
                      <span className="text-sm text-slate-300">{activity.user}</span>
                      <Badge variant="outline" className="text-xs">
                        {activity.country}
                      </Badge>
                    </div>
                    <Badge 
                      variant={activity.status === 'success' ? 'default' : 
                              activity.status === 'failed' ? 'destructive' : 'secondary'}
                      className="text-xs"
                    >
                      {activity.status}
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Hourly Trends */}
        <Card className="bg-slate-800 border-slate-700">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <BarChart3 className="h-5 w-5" />
              Hourly Login Trends
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-end justify-between h-40 gap-2">
              {loginInsights.hourlyTrends.map((trend, index) => (
                <div key={trend.hour} className="flex flex-col items-center flex-1">
                  <div 
                    className="bg-blue-500 w-full rounded-t"
                    style={{ height: `${(trend.logins / 250) * 100}%` }}
                  />
                  <div className="text-xs text-slate-400 mt-2">{trend.hour}</div>
                  <div className="text-xs text-white font-medium">{trend.logins}</div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Security Alerts */}
        <Card className="bg-slate-800 border-slate-700">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-red-400" />
              Security Alerts
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex items-center justify-between p-3 rounded bg-red-900/20 border border-red-800">
                <div>
                  <p className="text-red-400 font-medium">Multiple Failed Login Attempts</p>
                  <p className="text-sm text-slate-400">User: SUSP001-HACKER from IP: 192.168.1.100</p>
                </div>
                <Badge variant="destructive">High</Badge>
              </div>
              <div className="flex items-center justify-between p-3 rounded bg-yellow-900/20 border border-yellow-800">
                <div>
                  <p className="text-yellow-400 font-medium">Unusual Login Time</p>
                  <p className="text-sm text-slate-400">User: CORP002-JANE logged in at 3:22 AM</p>
                </div>
                <Badge variant="secondary">Medium</Badge>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default BackofficeDashboard;
