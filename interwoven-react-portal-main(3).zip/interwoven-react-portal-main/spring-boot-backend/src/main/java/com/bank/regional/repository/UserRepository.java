
package com.bank.regional.repository;

import com.bank.regional.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {
    Optional<User> findByOrganizationIdAndUserIdAndCountry(String organizationId, String userId, String country);
}
