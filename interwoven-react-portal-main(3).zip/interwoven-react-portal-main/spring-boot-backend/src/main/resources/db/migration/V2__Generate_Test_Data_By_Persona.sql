
-- Flyway Migration: Generate 1000 Test Users by Persona
-- This script creates comprehensive test data categorized by user personas
-- Distribution: 40% Corporate Finance Managers, 25% SME Business Owners, 
-- 20% Corporate Treasurers, 15% Finance Operations Specialists

-- =============================================================================
-- CORPORATE FINANCE MANAGER PERSONA (400 users - 40%)
-- Characteristics: High-volume transactions, multi-country operations, tech-savvy
-- =============================================================================

-- Singapore Corporate Finance Managers (80 users)
INSERT INTO users (organization_id, user_id, password, country, active, blocked)
SELECT 
    CASE 
        WHEN n <= 20 THEN 'ACME' || LPAD(FLOOR(1 + RAND() * 50), 3, '0')
        WHEN n <= 40 THEN 'MANU' || LPAD(FLOOR(1 + RAND() * 30), 3, '0')
        WHEN n <= 60 THEN 'TECH' || LPAD(FLOOR(1 + RAND() * 25), 3, '0')
        ELSE 'CORP' || LPAD(FLOOR(1 + RAND() * 40), 3, '0')
    END as organization_id,
    CONCAT('CFM', LPAD(n, 4, '0'), 'SG') as user_id,
    CONCAT('SecurePass', n, '!SG') as password,
    'SG' as country,
    CASE WHEN RAND() > 0.05 THEN true ELSE false END as active,
    CASE WHEN RAND() < 0.02 THEN true ELSE false END as blocked
FROM (
    SELECT @row := @row + 1 as n
    FROM information_schema.columns c1, information_schema.columns c2, (SELECT @row := 0) r
    LIMIT 80
) numbers;

-- Malaysia Corporate Finance Managers (60 users)
INSERT INTO users (organization_id, user_id, password, country, active, blocked)
SELECT 
    CASE 
        WHEN n <= 15 THEN 'PALM' || LPAD(FLOOR(1 + RAND() * 20), 3, '0')
        WHEN n <= 30 THEN 'GLOVE' || LPAD(FLOOR(1 + RAND() * 15), 3, '0')
        WHEN n <= 45 THEN 'LOGIS' || LPAD(FLOOR(1 + RAND() * 25), 3, '0')
        ELSE 'TRADE' || LPAD(FLOOR(1 + RAND() * 30), 3, '0')
    END as organization_id,
    CONCAT('CFM', LPAD(n, 4, '0'), 'MY') as user_id,
    CONCAT('SecurePass', n, '!MY') as password,
    'MY' as country,
    CASE WHEN RAND() > 0.05 THEN true ELSE false END as active,
    CASE WHEN RAND() < 0.02 THEN true ELSE false END as blocked
FROM (
    SELECT @row := @row + 1 as n
    FROM information_schema.columns c1, information_schema.columns c2, (SELECT @row := 0) r
    LIMIT 60
) numbers;

-- Hong Kong Corporate Finance Managers (80 users)
INSERT INTO users (organization_id, user_id, password, country, active, blocked)
SELECT 
    CASE 
        WHEN n <= 20 THEN 'MULTI' || LPAD(FLOOR(1 + RAND() * 30), 3, '0')
        WHEN n <= 40 THEN 'INVEST' || LPAD(FLOOR(1 + RAND() * 25), 3, '0')
        WHEN n <= 60 THEN 'HOLD' || LPAD(FLOOR(1 + RAND() * 35), 3, '0')
        ELSE 'WEALTH' || LPAD(FLOOR(1 + RAND() * 20), 3, '0')
    END as organization_id,
    CONCAT('CFM', LPAD(n, 4, '0'), 'HK') as user_id,
    CONCAT('SecurePass', n, '!HK') as password,
    'HK' as country,
    CASE WHEN RAND() > 0.05 THEN true ELSE false END as active,
    CASE WHEN RAND() < 0.02 THEN true ELSE false END as blocked
FROM (
    SELECT @row := @row + 1 as n
    FROM information_schema.columns c1, information_schema.columns c2, (SELECT @row := 0) r
    LIMIT 80
) numbers;

-- Indonesia Corporate Finance Managers (60 users)
INSERT INTO users (organization_id, user_id, password, country, active, blocked)
SELECT 
    CASE 
        WHEN n <= 15 THEN 'MINING' || LPAD(FLOOR(1 + RAND() * 20), 3, '0')
        WHEN n <= 30 THEN 'ENERGY' || LPAD(FLOOR(1 + RAND() * 15), 3, '0')
        WHEN n <= 45 THEN 'AGRI' || LPAD(FLOOR(1 + RAND() * 25), 3, '0')
        ELSE 'MANU' || LPAD(FLOOR(1 + RAND() * 30), 3, '0')
    END as organization_id,
    CONCAT('CFM', LPAD(n, 4, '0'), 'ID') as user_id,
    CONCAT('SecurePass', n, '!ID') as password,
    'ID' as country,
    CASE WHEN RAND() > 0.05 THEN true ELSE false END as active,
    CASE WHEN RAND() < 0.02 THEN true ELSE false END as blocked
FROM (
    SELECT @row := @row + 1 as n
    FROM information_schema.columns c1, information_schema.columns c2, (SELECT @row := 0) r
    LIMIT 60
) numbers;

-- China Corporate Finance Managers (70 users)
INSERT INTO users (organization_id, user_id, password, country, active, blocked)
SELECT 
    CASE 
        WHEN n <= 20 THEN 'SHANG' || LPAD(FLOOR(1 + RAND() * 50), 3, '0')
        WHEN n <= 40 THEN 'BEIJ' || LPAD(FLOOR(1 + RAND() * 40), 3, '0')
        WHEN n <= 55 THEN 'GUANG' || LPAD(FLOOR(1 + RAND() * 35), 3, '0')
        ELSE 'SHEN' || LPAD(FLOOR(1 + RAND() * 30), 3, '0')
    END as organization_id,
    CONCAT('CFM', LPAD(n, 4, '0'), 'CN') as user_id,
    CONCAT('SecurePass', n, '!CN') as password,
    'CN' as country,
    CASE WHEN RAND() > 0.05 THEN true ELSE false END as active,
    CASE WHEN RAND() < 0.02 THEN true ELSE false END as blocked
FROM (
    SELECT @row := @row + 1 as n
    FROM information_schema.columns c1, information_schema.columns c2, (SELECT @row := 0) r
    LIMIT 70
) numbers;

-- Vietnam Corporate Finance Managers (35 users)
INSERT INTO users (organization_id, user_id, password, country, active, blocked)
SELECT 
    CASE 
        WHEN n <= 10 THEN 'EXPORT' || LPAD(FLOOR(1 + RAND() * 20), 3, '0')
        WHEN n <= 20 THEN 'TEXT' || LPAD(FLOOR(1 + RAND() * 15), 3, '0')
        WHEN n <= 30 THEN 'ELECT' || LPAD(FLOOR(1 + RAND() * 25), 3, '0')
        ELSE 'FOOD' || LPAD(FLOOR(1 + RAND() * 30), 3, '0')
    END as organization_id,
    CONCAT('CFM', LPAD(n, 4, '0'), 'VN') as user_id,
    CONCAT('SecurePass', n, '!VN') as password,
    'VN' as country,
    CASE WHEN RAND() > 0.05 THEN true ELSE false END as active,
    CASE WHEN RAND() < 0.02 THEN true ELSE false END as blocked
FROM (
    SELECT @row := @row + 1 as n
    FROM information_schema.columns c1, information_schema.columns c2, (SELECT @row := 0) r
    LIMIT 35
) numbers;

-- Thailand Corporate Finance Managers (35 users)
INSERT INTO users (organization_id, user_id, password, country, active, blocked)
SELECT 
    CASE 
        WHEN n <= 10 THEN 'TOUR' || LPAD(FLOOR(1 + RAND() * 20), 3, '0')
        WHEN n <= 20 THEN 'AUTO' || LPAD(FLOOR(1 + RAND() * 15), 3, '0')
        WHEN n <= 30 THEN 'RICE' || LPAD(FLOOR(1 + RAND() * 25), 3, '0')
        ELSE 'HOTEL' || LPAD(FLOOR(1 + RAND() * 30), 3, '0')
    END as organization_id,
    CONCAT('CFM', LPAD(n, 4, '0'), 'TH') as user_id,
    CONCAT('SecurePass', n, '!TH') as password,
    'TH' as country,
    CASE WHEN RAND() > 0.05 THEN true ELSE false END as active,
    CASE WHEN RAND() < 0.02 THEN true ELSE false END as blocked
FROM (
    SELECT @row := @row + 1 as n
    FROM information_schema.columns c1, information_schema.columns c2, (SELECT @row := 0) r
    LIMIT 35
) numbers;

-- =============================================================================
-- SME BUSINESS OWNER PERSONA (250 users - 25%)
-- Characteristics: Cost-conscious, mobile-first, rapid growth businesses
-- =============================================================================

-- Singapore SME Business Owners (50 users)
INSERT INTO users (organization_id, user_id, password, country, active, blocked)
SELECT 
    CASE 
        WHEN n <= 15 THEN 'START' || LPAD(FLOOR(1 + RAND() * 30), 3, '0')
        WHEN n <= 30 THEN 'SMALL' || LPAD(FLOOR(1 + RAND() * 25), 3, '0')
        WHEN n <= 40 THEN 'RETAIL' || LPAD(FLOOR(1 + RAND() * 20), 3, '0')
        ELSE 'ECOMM' || LPAD(FLOOR(1 + RAND() * 35), 3, '0')
    END as organization_id,
    CONCAT('SME', LPAD(n, 4, '0'), 'SG') as user_id,
    CONCAT('BusinessPass', n, '@SG') as password,
    'SG' as country,
    CASE WHEN RAND() > 0.03 THEN true ELSE false END as active,
    CASE WHEN RAND() < 0.01 THEN true ELSE false END as blocked
FROM (
    SELECT @row := @row + 1 as n
    FROM information_schema.columns c1, information_schema.columns c2, (SELECT @row := 0) r
    LIMIT 50
) numbers;

-- Malaysia SME Business Owners (80 users)
INSERT INTO users (organization_id, user_id, password, country, active, blocked)
SELECT 
    CASE 
        WHEN n <= 25 THEN 'KEDAI' || LPAD(FLOOR(1 + RAND() * 40), 3, '0')
        WHEN n <= 50 THEN 'FAMLY' || LPAD(FLOOR(1 + RAND() * 35), 3, '0')
        WHEN n <= 65 THEN 'LOCAL' || LPAD(FLOOR(1 + RAND() * 30), 3, '0')
        ELSE 'GROW' || LPAD(FLOOR(1 + RAND() * 25), 3, '0')
    END as organization_id,
    CONCAT('SME', LPAD(n, 4, '0'), 'MY') as user_id,
    CONCAT('BusinessPass', n, '@MY') as password,
    'MY' as country,
    CASE WHEN RAND() > 0.03 THEN true ELSE false END as active,
    CASE WHEN RAND() < 0.01 THEN true ELSE false END as blocked
FROM (
    SELECT @row := @row + 1 as n
    FROM information_schema.columns c1, information_schema.columns c2, (SELECT @row := 0) r
    LIMIT 80
) numbers;

-- Hong Kong SME Business Owners (30 users)
INSERT INTO users (organization_id, user_id, password, country, active, blocked)
SELECT 
    CASE 
        WHEN n <= 10 THEN 'TRADE' || LPAD(FLOOR(1 + RAND() * 20), 3, '0')
        WHEN n <= 20 THEN 'IMPORT' || LPAD(FLOOR(1 + RAND() * 15), 3, '0')
        ELSE 'SERV' || LPAD(FLOOR(1 + RAND() * 25), 3, '0')
    END as organization_id,
    CONCAT('SME', LPAD(n, 4, '0'), 'HK') as user_id,
    CONCAT('BusinessPass', n, '@HK') as password,
    'HK' as country,
    CASE WHEN RAND() > 0.03 THEN true ELSE false END as active,
    CASE WHEN RAND() < 0.01 THEN true ELSE false END as blocked
FROM (
    SELECT @row := @row + 1 as n
    FROM information_schema.columns c1, information_schema.columns c2, (SELECT @row := 0) r
    LIMIT 30
) numbers;

-- Indonesia SME Business Owners (50 users)
INSERT INTO users (organization_id, user_id, password, country, active, blocked)
SELECT 
    CASE 
        WHEN n <= 15 THEN 'WARUNG' || LPAD(FLOOR(1 + RAND() * 30), 3, '0')
        WHEN n <= 30 THEN 'TOKO' || LPAD(FLOOR(1 + RAND() * 25), 3, '0')
        WHEN n <= 40 THEN 'CRAFT' || LPAD(FLOOR(1 + RAND() * 20), 3, '0')
        ELSE 'ONLINE' || LPAD(FLOOR(1 + RAND() * 35), 3, '0')
    END as organization_id,
    CONCAT('SME', LPAD(n, 4, '0'), 'ID') as user_id,
    CONCAT('BusinessPass', n, '@ID') as password,
    'ID' as country,
    CASE WHEN RAND() > 0.03 THEN true ELSE false END as active,
    CASE WHEN RAND() < 0.01 THEN true ELSE false END as blocked
FROM (
    SELECT @row := @row + 1 as n
    FROM information_schema.columns c1, information_schema.columns c2, (SELECT @row := 0) r
    LIMIT 50
) numbers;

-- China SME Business Owners (20 users)
INSERT INTO users (organization_id, user_id, password, country, active, blocked)
SELECT 
    CASE 
        WHEN n <= 7 THEN 'MINI' || LPAD(FLOOR(1 + RAND() * 15), 3, '0')
        WHEN n <= 14 THEN 'MICRO' || LPAD(FLOOR(1 + RAND() * 12), 3, '0')
        ELSE 'DIGIT' || LPAD(FLOOR(1 + RAND() * 18), 3, '0')
    END as organization_id,
    CONCAT('SME', LPAD(n, 4, '0'), 'CN') as user_id,
    CONCAT('BusinessPass', n, '@CN') as password,
    'CN' as country,
    CASE WHEN RAND() > 0.03 THEN true ELSE false END as active,
    CASE WHEN RAND() < 0.01 THEN true ELSE false END as blocked
FROM (
    SELECT @row := @row + 1 as n
    FROM information_schema.columns c1, information_schema.columns c2, (SELECT @row := 0) r
    LIMIT 20
) numbers;

-- Vietnam SME Business Owners (30 users)
INSERT INTO users (organization_id, user_id, password, country, active, blocked)
SELECT 
    CASE 
        WHEN n <= 10 THEN 'CAFE' || LPAD(FLOOR(1 + RAND() * 20), 3, '0')
        WHEN n <= 20 THEN 'SHOP' || LPAD(FLOOR(1 + RAND() * 15), 3, '0')
        ELSE 'FAMIL' || LPAD(FLOOR(1 + RAND() * 25), 3, '0')
    END as organization_id,
    CONCAT('SME', LPAD(n, 4, '0'), 'VN') as user_id,
    CONCAT('BusinessPass', n, '@VN') as password,
    'VN' as country,
    CASE WHEN RAND() > 0.03 THEN true ELSE false END as active,
    CASE WHEN RAND() < 0.01 THEN true ELSE false END as blocked
FROM (
    SELECT @row := @row + 1 as n
    FROM information_schema.columns c1, information_schema.columns c2, (SELECT @row := 0) r
    LIMIT 30
) numbers;

-- Thailand SME Business Owners (20 users)
INSERT INTO users (organization_id, user_id, password, country, active, blocked)
SELECT 
    CASE 
        WHEN n <= 7 THEN 'REST' || LPAD(FLOOR(1 + RAND() * 15), 3, '0')
        WHEN n <= 14 THEN 'MARKET' || LPAD(FLOOR(1 + RAND() * 12), 3, '0')
        ELSE 'CRAFT' || LPAD(FLOOR(1 + RAND() * 18), 3, '0')
    END as organization_id,
    CONCAT('SME', LPAD(n, 4, '0'), 'TH') as user_id,
    CONCAT('BusinessPass', n, '@TH') as password,
    'TH' as country,
    CASE WHEN RAND() > 0.03 THEN true ELSE false END as active,
    CASE WHEN RAND() < 0.01 THEN true ELSE false END as blocked
FROM (
    SELECT @row := @row + 1 as n
    FROM information_schema.columns c1, information_schema.columns c2, (SELECT @row := 0) r
    LIMIT 20
) numbers;

-- =============================================================================
-- CORPORATE TREASURER PERSONA (200 users - 20%)
-- Characteristics: Complex financial instruments, risk management focus
-- =============================================================================

-- Singapore Corporate Treasurers (50 users)
INSERT INTO users (organization_id, user_id, password, country, active, blocked)
SELECT 
    CASE 
        WHEN n <= 15 THEN 'TREAS' || LPAD(FLOOR(1 + RAND() * 30), 3, '0')
        WHEN n <= 30 THEN 'FUND' || LPAD(FLOOR(1 + RAND() * 25), 3, '0')
        WHEN n <= 40 THEN 'CASH' || LPAD(FLOOR(1 + RAND() * 20), 3, '0')
        ELSE 'RISK' || LPAD(FLOOR(1 + RAND() * 35), 3, '0')
    END as organization_id,
    CONCAT('TRS', LPAD(n, 4, '0'), 'SG') as user_id,
    CONCAT('TreasuryPass', n, '#SG') as password,
    'SG' as country,
    CASE WHEN RAND() > 0.02 THEN true ELSE false END as active,
    CASE WHEN RAND() < 0.005 THEN true ELSE false END as blocked
FROM (
    SELECT @row := @row + 1 as n
    FROM information_schema.columns c1, information_schema.columns c2, (SELECT @row := 0) r
    LIMIT 50
) numbers;

-- Malaysia Corporate Treasurers (25 users)
INSERT INTO users (organization_id, user_id, password, country, active, blocked)
SELECT 
    CASE 
        WHEN n <= 8 THEN 'GLCTRS' || LPAD(FLOOR(1 + RAND() * 15), 3, '0')
        WHEN n <= 16 THEN 'PLMTRS' || LPAD(FLOOR(1 + RAND() * 12), 3, '0')
        ELSE 'ENGTRS' || LPAD(FLOOR(1 + RAND() * 18), 3, '0')
    END as organization_id,
    CONCAT('TRS', LPAD(n, 4, '0'), 'MY') as user_id,
    CONCAT('TreasuryPass', n, '#MY') as password,
    'MY' as country,
    CASE WHEN RAND() > 0.02 THEN true ELSE false END as active,
    CASE WHEN RAND() < 0.005 THEN true ELSE false END as blocked
FROM (
    SELECT @row := @row + 1 as n
    FROM information_schema.columns c1, information_schema.columns c2, (SELECT @row := 0) r
    LIMIT 25
) numbers;

-- Hong Kong Corporate Treasurers (70 users)
INSERT INTO users (organization_id, user_id, password, country, active, blocked)
SELECT 
    CASE 
        WHEN n <= 20 THEN 'HKTRS' || LPAD(FLOOR(1 + RAND() * 40), 3, '0')
        WHEN n <= 40 THEN 'FINTRS' || LPAD(FLOOR(1 + RAND() * 35), 3, '0')
        WHEN n <= 55 THEN 'INVTRS' || LPAD(FLOOR(1 + RAND() * 30), 3, '0')
        ELSE 'HEDGTRS' || LPAD(FLOOR(1 + RAND() * 25), 3, '0')
    END as organization_id,
    CONCAT('TRS', LPAD(n, 4, '0'), 'HK') as user_id,
    CONCAT('TreasuryPass', n, '#HK') as password,
    'HK' as country,
    CASE WHEN RAND() > 0.02 THEN true ELSE false END as active,
    CASE WHEN RAND() < 0.005 THEN true ELSE false END as blocked
FROM (
    SELECT @row := @row + 1 as n
    FROM information_schema.columns c1, information_schema.columns c2, (SELECT @row := 0) r
    LIMIT 70
) numbers;

-- Indonesia Corporate Treasurers (20 users)
INSERT INTO users (organization_id, user_id, password, country, active, blocked)
SELECT 
    CASE 
        WHEN n <= 7 THEN 'IDTRS' || LPAD(FLOOR(1 + RAND() * 15), 3, '0')
        WHEN n <= 14 THEN 'MINTRS' || LPAD(FLOOR(1 + RAND() * 12), 3, '0')
        ELSE 'ENRTRS' || LPAD(FLOOR(1 + RAND() * 18), 3, '0')
    END as organization_id,
    CONCAT('TRS', LPAD(n, 4, '0'), 'ID') as user_id,
    CONCAT('TreasuryPass', n, '#ID') as password,
    'ID' as country,
    CASE WHEN RAND() > 0.02 THEN true ELSE false END as active,
    CASE WHEN RAND() < 0.005 THEN true ELSE false END as blocked
FROM (
    SELECT @row := @row + 1 as n
    FROM information_schema.columns c1, information_schema.columns c2, (SELECT @row := 0) r
    LIMIT 20
) numbers;

-- China Corporate Treasurers (25 users)
INSERT INTO users (organization_id, user_id, password, country, active, blocked)
SELECT 
    CASE 
        WHEN n <= 8 THEN 'CNTRS' || LPAD(FLOOR(1 + RAND() * 15), 3, '0')
        WHEN n <= 16 THEN 'SOCTRS' || LPAD(FLOOR(1 + RAND() * 12), 3, '0')
        ELSE 'STATRS' || LPAD(FLOOR(1 + RAND() * 18), 3, '0')
    END as organization_id,
    CONCAT('TRS', LPAD(n, 4, '0'), 'CN') as user_id,
    CONCAT('TreasuryPass', n, '#CN') as password,
    'CN' as country,
    CASE WHEN RAND() > 0.02 THEN true ELSE false END as active,
    CASE WHEN RAND() < 0.005 THEN true ELSE false END as blocked
FROM (
    SELECT @row := @row + 1 as n
    FROM information_schema.columns c1, information_schema.columns c2, (SELECT @row := 0) r
    LIMIT 25
) numbers;

-- Vietnam Corporate Treasurers (7 users)
INSERT INTO users (organization_id, user_id, password, country, active, blocked)
SELECT 
    CONCAT('VNTRS', LPAD(FLOOR(1 + RAND() * 10), 3, '0')) as organization_id,
    CONCAT('TRS', LPAD(n, 4, '0'), 'VN') as user_id,
    CONCAT('TreasuryPass', n, '#VN') as password,
    'VN' as country,
    CASE WHEN RAND() > 0.02 THEN true ELSE false END as active,
    CASE WHEN RAND() < 0.005 THEN true ELSE false END as blocked
FROM (
    SELECT @row := @row + 1 as n
    FROM information_schema.columns c1, information_schema.columns c2, (SELECT @row := 0) r
    LIMIT 7
) numbers;

-- Thailand Corporate Treasurers (3 users)
INSERT INTO users (organization_id, user_id, password, country, active, blocked)
SELECT 
    CONCAT('THTRS', LPAD(FLOOR(1 + RAND() * 5), 3, '0')) as organization_id,
    CONCAT('TRS', LPAD(n, 4, '0'), 'TH') as user_id,
    CONCAT('TreasuryPass', n, '#TH') as password,
    'TH' as country,
    CASE WHEN RAND() > 0.02 THEN true ELSE false END as active,
    CASE WHEN RAND() < 0.005 THEN true ELSE false END as blocked
FROM (
    SELECT @row := @row + 1 as n
    FROM information_schema.columns c1, information_schema.columns c2, (SELECT @row := 0) r
    LIMIT 3
) numbers;

-- =============================================================================
-- FINANCE OPERATIONS SPECIALIST PERSONA (150 users - 15%)
-- Characteristics: High-frequency users, batch processing, detail-oriented
-- =============================================================================

-- Singapore Finance Operations Specialists (30 users)
INSERT INTO users (organization_id, user_id, password, country, active, blocked)
SELECT 
    CASE 
        WHEN n <= 10 THEN 'FINOPS' || LPAD(FLOOR(1 + RAND() * 20), 3, '0')
        WHEN n <= 20 THEN 'PROCSS' || LPAD(FLOOR(1 + RAND() * 15), 3, '0')
        ELSE 'BATCH' || LPAD(FLOOR(1 + RAND() * 25), 3, '0')
    END as organization_id,
    CONCAT('FOS', LPAD(n, 4, '0'), 'SG') as user_id,
    CONCAT('OperationsPass', n, '$SG') as password,
    'SG' as country,
    CASE WHEN RAND() > 0.01 THEN true ELSE false END as active,
    CASE WHEN RAND() < 0.005 THEN true ELSE false END as blocked
FROM (
    SELECT @row := @row + 1 as n
    FROM information_schema.columns c1, information_schema.columns c2, (SELECT @row := 0) r
    LIMIT 30
) numbers;

-- Malaysia Finance Operations Specialists (35 users)
INSERT INTO users (organization_id, user_id, password, country, active, blocked)
SELECT 
    CASE 
        WHEN n <= 12 THEN 'MYOPS' || LPAD(FLOOR(1 + RAND() * 25), 3, '0')
        WHEN n <= 24 THEN 'PAYOPS' || LPAD(FLOOR(1 + RAND() * 20), 3, '0')
        ELSE 'RECOPS' || LPAD(FLOOR(1 + RAND() * 30), 3, '0')
    END as organization_id,
    CONCAT('FOS', LPAD(n, 4, '0'), 'MY') as user_id,
    CONCAT('OperationsPass', n, '$MY') as password,
    'MY' as country,
    CASE WHEN RAND() > 0.01 THEN true ELSE false END as active,
    CASE WHEN RAND() < 0.005 THEN true ELSE false END as blocked
FROM (
    SELECT @row := @row + 1 as n
    FROM information_schema.columns c1, information_schema.columns c2, (SELECT @row := 0) r
    LIMIT 35
) numbers;

-- Hong Kong Finance Operations Specialists (25 users)
INSERT INTO users (organization_id, user_id, password, country, active, blocked)
SELECT 
    CASE 
        WHEN n <= 8 THEN 'HKOPS' || LPAD(FLOOR(1 + RAND() * 20), 3, '0')
        WHEN n <= 16 THEN 'TRDOPS' || LPAD(FLOOR(1 + RAND() * 15), 3, '0')
        ELSE 'FXOPS' || LPAD(FLOOR(1 + RAND() * 25), 3, '0')
    END as organization_id,
    CONCAT('FOS', LPAD(n, 4, '0'), 'HK') as user_id,
    CONCAT('OperationsPass', n, '$HK') as password,
    'HK' as country,
    CASE WHEN RAND() > 0.01 THEN true ELSE false END as active,
    CASE WHEN RAND() < 0.005 THEN true ELSE false END as blocked
FROM (
    SELECT @row := @row + 1 as n
    FROM information_schema.columns c1, information_schema.columns c2, (SELECT @row := 0) r
    LIMIT 25
) numbers;

-- Indonesia Finance Operations Specialists (40 users)
INSERT INTO users (organization_id, user_id, password, country, active, blocked)
SELECT 
    CASE 
        WHEN n <= 13 THEN 'IDOPS' || LPAD(FLOOR(1 + RAND() * 30), 3, '0')
        WHEN n <= 26 THEN 'EXPOPS' || LPAD(FLOOR(1 + RAND() * 25), 3, '0')
        ELSE 'IMPOPS' || LPAD(FLOOR(1 + RAND() * 35), 3, '0')
    END as organization_id,
    CONCAT('FOS', LPAD(n, 4, '0'), 'ID') as user_id,
    CONCAT('OperationsPass', n, '$ID') as password,
    'ID' as country,
    CASE WHEN RAND() > 0.01 THEN true ELSE false END as active,
    CASE WHEN RAND() < 0.005 THEN true ELSE false END as blocked
FROM (
    SELECT @row := @row + 1 as n
    FROM information_schema.columns c1, information_schema.columns c2, (SELECT @row := 0) r
    LIMIT 40
) numbers;

-- China Finance Operations Specialists (10 users)
INSERT INTO users (organization_id, user_id, password, country, active, blocked)
SELECT 
    CASE 
        WHEN n <= 3 THEN 'CNOPS' || LPAD(FLOOR(1 + RAND() * 10), 3, '0')
        WHEN n <= 6 THEN 'FACOPS' || LPAD(FLOOR(1 + RAND() * 8), 3, '0')
        ELSE 'MFGOPS' || LPAD(FLOOR(1 + RAND() * 12), 3, '0')
    END as organization_id,
    CONCAT('FOS', LPAD(n, 4, '0'), 'CN') as user_id,
    CONCAT('OperationsPass', n, '$CN') as password,
    'CN' as country,
    CASE WHEN RAND() > 0.01 THEN true ELSE false END as active,
    CASE WHEN RAND() < 0.005 THEN true ELSE false END as blocked
FROM (
    SELECT @row := @row + 1 as n
    FROM information_schema.columns c1, information_schema.columns c2, (SELECT @row := 0) r
    LIMIT 10
) numbers;

-- Vietnam Finance Operations Specialists (6 users)
INSERT INTO users (organization_id, user_id, password, country, active, blocked)
SELECT 
    CONCAT('VNOPS', LPAD(FLOOR(1 + RAND() * 8), 3, '0')) as organization_id,
    CONCAT('FOS', LPAD(n, 4, '0'), 'VN') as user_id,
    CONCAT('OperationsPass', n, '$VN') as password,
    'VN' as country,
    CASE WHEN RAND() > 0.01 THEN true ELSE false END as active,
    CASE WHEN RAND() < 0.005 THEN true ELSE false END as blocked
FROM (
    SELECT @row := @row + 1 as n
    FROM information_schema.columns c1, information_schema.columns c2, (SELECT @row := 0) r
    LIMIT 6
) numbers;

-- Thailand Finance Operations Specialists (4 users)
INSERT INTO users (organization_id, user_id, password, country, active, blocked)
SELECT 
    CONCAT('THOPS', LPAD(FLOOR(1 + RAND() * 6), 3, '0')) as organization_id,
    CONCAT('FOS', LPAD(n, 4, '0'), 'TH') as user_id,
    CONCAT('OperationsPass', n, '$TH') as password,
    'TH' as country,
    CASE WHEN RAND() > 0.01 THEN true ELSE false END as active,
    CASE WHEN RAND() < 0.005 THEN true ELSE false END as blocked
FROM (
    SELECT @row := @row + 1 as n
    FROM information_schema.columns c1, information_schema.columns c2, (SELECT @row := 0) r
    LIMIT 4
) numbers;

-- =============================================================================
-- PERSONA-SPECIFIC CONTENT DATA GENERATION
-- Enhanced content based on persona characteristics and preferences
-- =============================================================================

-- Clear existing content data to avoid duplicates
DELETE FROM content_data;

-- Corporate Finance Manager focused content (premium, efficiency-focused)
INSERT INTO content_data (country, language, content_type, content_data, background_url) VALUES
-- Singapore CFM Content
('SG', 'en', 'banner', '{"title":"Corporate Finance Excellence","subtitle":"Advanced cash management solutions for finance leaders","ctaText":"Explore Dashboard","priority":"efficiency"}', '/images/sg-corporate-banner.jpg'),
('SG', 'zh', 'banner', '{"title":"企业财务卓越","subtitle":"为财务领导者提供先进的现金管理解决方案","ctaText":"探索仪表板","priority":"efficiency"}', '/images/sg-corporate-banner-zh.jpg'),
('SG', 'en', 'announcement', 'CFM Alert: New multi-currency hedging tools now available. Optimize your FX exposure management with our enhanced risk analytics dashboard.', null),
('SG', 'zh', 'announcement', 'CFM警告：现已提供新的多币种对冲工具。通过我们增强的风险分析仪表板优化您的外汇风险管理。', null),

-- Malaysia CFM Content
('MY', 'en', 'banner', '{"title":"Malaysia Corporate Banking","subtitle":"Streamline operations across ASEAN markets","ctaText":"Access Tools","priority":"regional"}', '/images/my-corporate-banner.jpg'),
('MY', 'zh', 'banner', '{"title":"马来西亚企业银行","subtitle":"简化东盟市场业务","ctaText":"访问工具","priority":"regional"}', '/images/my-corporate-banner-zh.jpg'),
('MY', 'en', 'announcement', 'CFM Update: ASEAN payment corridors expanded. New direct settlement options for Thailand and Indonesia cross-border payments.', null),

-- Hong Kong CFM Content
('HK', 'en', 'banner', '{"title":"Hong Kong Financial Hub","subtitle":"Gateway to Greater China corporate finance","ctaText":"Manage Portfolios","priority":"international"}', '/images/hk-corporate-banner.jpg'),
('HK', 'zh', 'banner', '{"title":"香港金融中心","subtitle":"大中华区企业金融门户","ctaText":"管理投资组合","priority":"international"}', '/images/hk-corporate-banner-zh.jpg'),
('HK', 'en', 'announcement', 'CFM Notice: Enhanced connectivity to Shanghai and Shenzhen markets. New trade finance instruments available for Belt & Road initiatives.', null),

-- SME Business Owner focused content (cost-effective, growth-oriented)
-- Singapore SME Content
('SG', 'en', 'banner', '{"title":"Grow Your Business","subtitle":"Affordable banking solutions for Singapore SMEs","ctaText":"Start Growing","priority":"growth"}', '/images/sg-sme-banner.jpg'),
('SG', 'en', 'announcement', 'SME Special: Reduced transaction fees for startups under 2 years. Apply for growth credit facilities with expedited approval process.', null),

-- Malaysia SME Content
('MY', 'en', 'banner', '{"title":"Usahawan Malaysia","subtitle":"Banking yang mudah untuk perniagaan kecil","ctaText":"Mula Sekarang","priority":"local"}', '/images/my-sme-banner.jpg'),
('MY', 'en', 'announcement', 'SME Promotion: Free mobile banking for businesses with monthly turnover under RM50,000. Islamic banking options available.', null),

-- Corporate Treasurer focused content (sophisticated, risk-focused)
-- Hong Kong Treasurer Content
('HK', 'en', 'banner', '{"title":"Treasury Management Hub","subtitle":"Sophisticated liquidity and risk management tools","ctaText":"Access Treasury","priority":"sophistication"}', '/images/hk-treasury-banner.jpg'),
('HK', 'zh', 'banner', '{"title":"资金管理中心","subtitle":"先进的流动性和风险管理工具","ctaText":"访问资金管理","priority":"sophistication"}', '/images/hk-treasury-banner-zh.jpg'),
('HK', 'en', 'announcement', 'Treasury Alert: New derivatives trading platform launched. Enhanced yield curve analytics and scenario modeling capabilities.', null),

-- Singapore Treasurer Content
('SG', 'en', 'banner', '{"title":"Singapore Treasury Solutions","subtitle":"Advanced cash pooling and investment management","ctaText":"Optimize Cash","priority":"optimization"}', '/images/sg-treasury-banner.jpg'),
('SG', 'en', 'announcement', 'Treasury Update: Real-time liquidity monitoring across APAC subsidiaries. New ESG investment products for corporate treasuries.', null),

-- Finance Operations Specialist focused content (efficiency, automation)
-- Indonesia FOS Content
('ID', 'en', 'banner', '{"title":"Operasi Keuangan Efisien","subtitle":"Otomasi proses pembayaran dan rekonsiliasi","ctaText":"Mulai Otomasi","priority":"automation"}', '/images/id-operations-banner.jpg'),
('ID', 'en', 'announcement', 'Operations Update: Bulk payment processing now supports 10,000+ transactions per batch. API integration guides available.', null),

-- Malaysia FOS Content
('MY', 'en', 'banner', '{"title":"Financial Operations Center","subtitle":"Streamlined transaction processing for Malaysian businesses","ctaText":"Process Now","priority":"efficiency"}', '/images/my-operations-banner.jpg'),
('MY', 'en', 'announcement', 'FOS Enhancement: Auto-reconciliation for EPF and SOCSO payments. Reduce manual processing time by 80% with new workflows.', null),

-- Background images tailored to personas
('SG', 'en', 'background', null, '/lovable-uploads/6fffa759-a2a4-48dc-9970-6f351d662bb6.png'),
('SG', 'zh', 'background', null, '/lovable-uploads/6fffa759-a2a4-48dc-9970-6f351d662bb6.png'),
('MY', 'en', 'background', null, '/lovable-uploads/74270c80-e3ec-4d8f-9496-fb485151e630.png'),
('MY', 'zh', 'background', null, '/lovable-uploads/74270c80-e3ec-4d8f-9496-fb485151e630.png'),
('HK', 'en', 'background', null, '/lovable-uploads/50fa8cab-c0a5-4561-a9d4-96ffe18280be.png'),
('HK', 'zh', 'background', null, '/lovable-uploads/50fa8cab-c0a5-4561-a9d4-96ffe18280be.png'),
('ID', 'en', 'background', null, '/lovable-uploads/606edb96-ab52-45a7-8e41-b055b2b51b6e.png'),
('CN', 'en', 'background', null, '/lovable-uploads/6fffa759-a2a4-48dc-9970-6f351d662bb6.png'),
('CN', 'zh', 'background', null, '/lovable-uploads/6fffa759-a2a4-48dc-9970-6f351d662bb6.png'),
('VN', 'en', 'background', null, '/lovable-uploads/74270c80-e3ec-4d8f-9496-fb485151e630.png'),
('TH', 'en', 'background', null, '/lovable-uploads/50fa8cab-c0a5-4561-a9d4-96ffe18280be.png');

-- =============================================================================
-- DATA VALIDATION AND SUMMARY
-- =============================================================================

-- Create a summary view of generated test data
SELECT 
    'Corporate Finance Managers' as persona_type,
    country,
    COUNT(*) as user_count
FROM users 
WHERE user_id LIKE 'CFM%'
GROUP BY country

UNION ALL

SELECT 
    'SME Business Owners' as persona_type,
    country,
    COUNT(*) as user_count
FROM users 
WHERE user_id LIKE 'SME%'
GROUP BY country

UNION ALL

SELECT 
    'Corporate Treasurers' as persona_type,
    country,
    COUNT(*) as user_count
FROM users 
WHERE user_id LIKE 'TRS%'
GROUP BY country

UNION ALL

SELECT 
    'Finance Operations Specialists' as persona_type,
    country,
    COUNT(*) as user_count
FROM users 
WHERE user_id LIKE 'FOS%'
GROUP BY country

ORDER BY persona_type, country;

-- Final count verification
SELECT 
    COUNT(*) as total_users_generated,
    COUNT(CASE WHEN active = true THEN 1 END) as active_users,
    COUNT(CASE WHEN blocked = true THEN 1 END) as blocked_users,
    COUNT(DISTINCT country) as countries_covered,
    COUNT(DISTINCT organization_id) as organizations_created
FROM users;

-- Content data summary
SELECT 
    country,
    language,
    content_type,
    COUNT(*) as content_pieces
FROM content_data
GROUP BY country, language, content_type
ORDER BY country, language, content_type;

