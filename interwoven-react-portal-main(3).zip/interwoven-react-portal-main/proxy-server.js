
const express = require('express');
const { createProxyMiddleware } = require('http-proxy-middleware');
const cors = require('cors');

const app = express();

// Enable CORS for all routes
app.use(cors({
  origin: [
    'http://localhost:5173',
    'http://localhost:3000',
    'https://mfe-dbr-tasks-sg.apps.dev.ocbc.com',
    'https://099637ab-c175-48ca-85f2-c844ee081a75.lovableproject.com'
  ],
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'Accept', 'Cache-Control']
}));

// Proxy middleware for Bitbucket requests
app.use('/bitbucket', createProxyMiddleware({
  target: 'https://bitbucket.ocbc.com',
  changeOrigin: true,
  secure: true, // Set to false if using self-signed certificates
  pathRewrite: {
    '^/bitbucket': '' // Remove /bitbucket prefix when forwarding
  },
  onProxyReq: (proxyReq, req, res) => {
    console.log(`[${new Date().toISOString()}] Proxying: ${req.method} ${req.url} -> ${proxyReq.getHeader('host')}${proxyReq.path}`);
  },
  onProxyRes: (proxyRes, req, res) => {
    console.log(`[${new Date().toISOString()}] Response: ${proxyRes.statusCode} for ${req.url}`);
    
    // Add CORS headers to the response
    proxyRes.headers['Access-Control-Allow-Origin'] = req.headers.origin || '*';
    proxyRes.headers['Access-Control-Allow-Credentials'] = 'true';
    proxyRes.headers['Access-Control-Allow-Methods'] = 'GET, POST, PUT, DELETE, OPTIONS';
    proxyRes.headers['Access-Control-Allow-Headers'] = 'Content-Type, Authorization, Accept, Cache-Control';
  },
  onError: (err, req, res) => {
    console.error(`[${new Date().toISOString()}] Proxy Error:`, err.message);
    res.status(500).json({
      error: 'Proxy Error',
      message: err.message,
      timestamp: new Date().toISOString()
    });
  }
}));

// Health check endpoint
app.get('/health', (req, res) => {
  res.json({
    status: 'OK',
    timestamp: new Date().toISOString(),
    message: 'Proxy server is running'
  });
});

// Handle preflight requests
app.options('*', (req, res) => {
  res.header('Access-Control-Allow-Origin', req.headers.origin || '*');
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization, Accept, Cache-Control');
  res.header('Access-Control-Allow-Credentials', 'true');
  res.sendStatus(200);
});

const PORT = process.env.PORT || 3001;

app.listen(PORT, () => {
  console.log(`=================================`);
  console.log(`🚀 Proxy server running on port ${PORT}`);
  console.log(`📡 Proxying requests to: https://bitbucket.ocbc.com`);
  console.log(`🌐 Health check: http://localhost:${PORT}/health`);
  console.log(`📝 Usage example:`);
  console.log(`   Frontend URL: http://localhost:${PORT}/bitbucket/projects/OCMFE/repos/mfe-dbr-tasks/raw/public/announcement.txt`);
  console.log(`   Maps to: https://bitbucket.ocbc.com/projects/OCMFE/repos/mfe-dbr-tasks/raw/public/announcement.txt`);
  console.log(`=================================`);
});

// Graceful shutdown
process.on('SIGINT', () => {
  console.log('\n🛑 Proxy server shutting down gracefully...');
  process.exit(0);
});

process.on('SIGTERM', () => {
  console.log('\n🛑 Proxy server shutting down gracefully...');
  process.exit(0);
});
