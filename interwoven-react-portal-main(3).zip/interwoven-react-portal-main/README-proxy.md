
# Bitbucket CORS Proxy Server

This proxy server resolves CORS issues when accessing Bitbucket resources from your frontend application.

## Setup Instructions

### 1. Install Dependencies

```bash
# Install Node.js dependencies
npm install express http-proxy-middleware cors
```

### 2. Start the Proxy Server

**On Linux/Mac:**
```bash
chmod +x start-proxy.sh
./start-proxy.sh
```

**On Windows:**
```cmd
start-proxy.bat
```

**Manual start:**
```bash
node proxy-server.js
```

### 3. Update Your AppConfig

Once the proxy is running, update your `src/config/AppConfig.ts` URLs:

```typescript
private static backgroundConfig: BackgroundConfig = {
  loginBackgroundUrl: 'http://localhost:3001/bitbucket/projects/OCMFE/repos/mfe-dbr-tasks/raw/public/bank-up/background.png',
  fallbackBackgroundUrl: '/lovable-uploads/6fffa759-a2a4-48dc-9970-6f351d662bb6.png'
};

private static securityNoticeConfig: SecurityNoticeConfig = {
  announcementUrl: 'http://localhost:3001/bitbucket/projects/OCMFE/repos/mfe-dbr-tasks/raw/public/announcement.txt',
  fallbackNotice: {
    en: 'Security advisory...',
    zh: '安全提醒...'
  }
};

private static needHelpConfig: NeedHelpConfig = {
  contentUrl: 'http://localhost:3001/bitbucket/projects/OCMFE/repos/mfe-dbr-tasks/raw/public/help-content.txt'
};
```

## How It Works

- The proxy server runs on `http://localhost:3001`
- All requests to `/bitbucket/*` are forwarded to `https://bitbucket.ocbc.com/*`
- CORS headers are automatically added to responses
- Supports all HTTP methods (GET, POST, PUT, DELETE, OPTIONS)

## Testing

Visit `http://localhost:3001/health` to verify the proxy is running.

## Troubleshooting

1. **Port already in use**: Change the PORT in proxy-server.js
2. **Network errors**: Check your connection to bitbucket.ocbc.com
3. **SSL certificate issues**: Set `secure: false` in the proxy configuration for self-signed certificates

## Security Notes

- This proxy is for development use only
- In production, configure proper CORS headers on your Bitbucket server
- The proxy logs all requests for debugging purposes
