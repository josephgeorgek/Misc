@login @functional
Feature: Multi-Country Banking Login Portal
  As a regional bank customer
  I want to securely access my banking application
  So that I can manage my financial activities

  Background:
    Given I am on the regional bank login page
    And the page loads successfully

  @positive @pre_approved_loans
  Scenario Outline: Validate the Pre Approved Loan Banner is visible to Authorized user whose CIF number matches with ML Loans
    Given the user login to the Web Application with credentials <orgId> org name <username> username and <password> password for <country>
    When they navigate to the main menu and select Portfolio Summary page
    Then validate Pre approved loan banner is displayed
    And the user logout from web application

    Examples:
      | orgId    | username    | password   | country   |
      | CORP-123 | JOHN-130    | pass@123   | Singapore |
      | ACME-456 | PALL2040    | login@456  | Singapore |

  @negative @pre_approved_loans  
  Scenario Outline: Validate the Pre Approved Loan Banner is not visible to user whose CIF does not matches with ML Loans
    Given the user login to the Web Application with credentials <orgId> org name <username> username and <password> password for <country>
    When they navigate to the main menu and select Portfolio Summary page  
    Then user clicks on overview from Accounts Menu and Landing in portfolio summary page
    Then validate Pre approved loan banner is not displayed
    And the user logout from web application

    Examples:
      | orgId    | username | password | country   |
      | FAIL     | PALL2045 | pass@123 | Singapore |

  @positive @authorized_users
  Scenario Outline: Validate the Pre Approved Loan Banner is visible only to user who have not exceeded the AFL offer already
    Given the user login to the Web Application with credentials <orgId> org name <username> username and <password> password for <country>
    When they navigate to the main menu and select Portfolio Summary page
    Then validate Pre approved loan banner is displayed based on their eligibility acceptance status
    And validate PAL Banner is displayed based on their AFL offer acceptance status  
    And the user logout from web application

    Examples:
      | orgId    | username | password | country   |
      | CORP-132 | username | pass@123 | Singapore |

  @smoke @basic_login
  Scenario Outline: Successful login with valid credentials
    Given I select country "<country>"
    When I enter organization ID "<orgId>"
    And I enter user ID "<userId>"  
    And I enter password "<password>"
    And I click the login button
    Then I should be redirected to the dashboard
    And I should see a welcome message containing "<userId>"

    Examples:
      | country   | orgId    | userId    | password    |
      | SG        | ACME001  | JOHNDOE   | password123 |
      | MY        | CORP002  | AHMAD     | password456 |
      | HK        | ACME001  | WONG      | password123 |
      | ID        | CORP002  | BUDI      | password456 |

  @negative @invalid_credentials
  Scenario Outline: Login failure with invalid credentials
    Given I select country "<country>"
    When I enter organization ID "<orgId>"
    And I enter user ID "<userId>"
    And I enter password "<password>"
    And I click the login button
    Then I should see an error message
    And I should remain on the login page

    Examples:
      | country | orgId    | userId    | password    |
      | SG      | INVALID  | JOHNDOE   | password123 |
      | SG      | ACME001  | INVALID   | password123 |
      | SG      | ACME001  | JOHNDOE   | wrongpass   |

  @functionality @country_selection
  Scenario: Country selection affects form behavior
    Given I am on the login page
    When I select different countries from the dropdown
    Then the form should adapt to country-specific requirements
    And the language toggle should reflect appropriate options

  @functionality @language_toggle
  Scenario Outline: Language toggle functionality
    Given I select country "<country>"
    When I toggle the language to "<language>"
    Then all text elements should display in "<language>"
    And form placeholders should be translated appropriately

    Examples:
      | country | language |
      | SG      | en       |
      | SG      | zh       |
      | MY      | en       |
      | CN      | zh       |

  @security @password_validation
  Scenario: Password field security features
    Given I am on the login page
    When I enter a password
    Then the password should be masked by default
    When I click the show/hide password toggle
    Then the password visibility should change accordingly

  @accessibility @need_help
  Scenario: Need Help functionality
    Given I am on the login page
    When I click the "Need Help" button
    Then a help dialog should open
    And I should see relevant assistance options

  @accessibility @reset_password
  Scenario: Password reset functionality
    Given I am on the login page
    When I click the "Reset Password" button
    Then a password reset wizard should open
    And I should be guided through the reset process

  @accessibility @new_user
  Scenario: New user registration
    Given I am on the login page
    When I click the "New User" button
    Then a new user wizard should open
    And I should be guided through the registration process

  @performance @page_load
  Scenario: Page load performance
    Given I navigate to the login page
    Then the page should load within 3 seconds
    And all critical elements should be visible
    And the country selector should be functional

  @responsive @mobile_view
  Scenario: Mobile responsive design
    Given I access the login page on a mobile device
    Then the layout should adapt appropriately
    And all functionality should remain accessible
    And touch targets should be appropriately sized