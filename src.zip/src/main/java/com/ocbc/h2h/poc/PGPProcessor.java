package com.ocbc.h2h.poc;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.component.exec.ExecResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
public class PGPProcessor implements Processor {

    private static final Logger logger = LoggerFactory.getLogger(PGPProcessor.class);
    public PGPProcessor()
    {

    }
    public void process(Exchange exchange)  {
        logger.info("Processing for "+exchange.getExchangeId());

        logger.info(exchange.getIn().getBody().toString());
        // Use the Camel Exec String type converter to convert the ExecResult to String
        // In this case, the stdout is considered as output
        String wordCountOutput = exchange.getIn().getBody(String.class);
        logger.info((String) wordCountOutput);
        // do something with the word count
        logger.error("Unexpected exception", exchange.getException());
    }
}