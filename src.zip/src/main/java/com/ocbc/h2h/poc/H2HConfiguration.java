/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.ocbc.h2h.poc;

import org.apache.camel.BindToRegistry;
import org.apache.camel.PropertyInject;
import org.springframework.context.annotation.Bean;



/**
 * Class to configure the Camel application.
 */
public class H2HConfiguration {

	 @Bean(name = "startend")
	  @BindToRegistry
    public FW processor(@PropertyInject("hi") String hi, @PropertyInject("bye") String bye) {
        // this will create an instance of this bean with the name of the method (eg myBean)
        return new FW(hi, bye);
    }

	 @Bean(name = "processor")
	  @BindToRegistry
    public FW fw(@PropertyInject("hi") String hi, @PropertyInject("bye") String bye) {
        // this will create an instance of this bean with the name of the method (eg myBean)
        return new FW(hi, bye);
    }
	 
	 @Bean(name = "h2hProcessor")
	  @BindToRegistry
   public H2HProcessor h2hProcessor() {
       // this will create an instance of this bean with the name of the method (eg myBean)
       return new H2HProcessor();
   }

    public void configure() {
        // this method is optional and can be removed if no additional configuration is needed.
    	
    }

}
