package com.ocbc.h2h.poc;

import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.rest.RestBindingMode;

/**
 * Notice this route is in Java code, but hawtio can visualize the route in the web browser
 * and you can add breakpoints and debug the route.
 */
public class RestRouteBuilder extends RouteBuilder {

    public void configure() {
    	//restConfiguration().component("restlet").port(9080);
    ///	restConfiguration().component("netty-http4").host("localhost").port(9090).bindingMode(RestBindingMode.auto);

    	 String listenAddress = "0.0.0.0";
         int listenPort = 8081;

         restConfiguration().component("jetty").host(listenAddress).port(listenPort).bindingMode(RestBindingMode.json);


         rest("/pgp-notifier")
                 .post()
                 .produces("application/json")
                 .to("direct:pgp-decrypt");
         
        rest("/rest").consumes("application/text").produces("application/text")

            // ping rest service
            .get("ping")
                .route().routeId("ping")
                .transform(constant("PONG\n"))
            .endRest()

            // controlbus to start/stop the route
            .get("route/{action}")
                // use dynamic-to so the action is provided from the url
                .toD("controlbus:route?routeId=ping&action=${header.action}");

    }

}
