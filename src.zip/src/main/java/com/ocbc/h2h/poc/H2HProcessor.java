package com.ocbc.h2h.poc;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
public class H2HProcessor implements Processor {

    private static final Logger logger = LoggerFactory.getLogger(H2HProcessor.class);
    public H2HProcessor()
    {

    }
    public void process(Exchange exchange)  {
        logger.info("Processing for "+exchange.getExchangeId());

        String filepath =  exchange.getIn().getHeader("CamelFileParent").toString();
	    	String[] paths = filepath.split("H2H", 2);
	    	
	    	filepath = paths[0]+"PGP"+paths[1];
        exchange.getIn().setHeader("PGPPATH", filepath);
        exchange.getIn().setHeader("CamelFileName", exchange.getIn().getHeader("CamelFileNameOnly"));
        logger.error("Unexpected exception", exchange.getException());
    }
}