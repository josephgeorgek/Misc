package com.ocbc.h2h.poc;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.context.annotation.Bean;



public class FileConsumerRoute extends RouteBuilder {

    private int delay = 100;
    private String name;

	/*
	 * public FileConsumerRoute(String name, int delay) { this.name = name;
	 * this.delay = delay; }
	 */

    @Override
    public void configure() throws Exception {
        // read files from the shared directory
        from("file:target/inbox" +
                "?delete=true")
            // setup route policy to be used
            .routePolicyRef("myPolicy")
            .log( " - Received file: ${file:name}")
            .delay(delay)
            .log(" - Done file:     ${file:name}")
            .to("file:target/outbox");
        
        from("file-watch:/Users/josephgeorge/dev/camel/H2H/keppel?events=CREATE&antInclude=**/*.ACK*").routeId("H2H_ACK")
        .routePolicyRef("myPolicy")
        .log("AUDITLOG: ${header.CamelFileEventType} occurred on file ${header.CamelFileAbsolutePath} at ${header.CamelFileLastModified}")
     
       // .bean(FW.class, "watch")
        .process(new Processor() {
 		    public void process(Exchange exchange) throws Exception {
 		    
 		    	String filepath =  exchange.getIn().getHeader("CamelFileParent").toString();
 		    	String[] paths = filepath.split("H2H", 2);
 		    	
 		    	filepath = paths[0]+"PGP"+paths[1];
                exchange.getIn().setHeader("PGPPATH", filepath);
                exchange.getIn().setHeader("CamelFileName", exchange.getIn().getHeader("CamelFileNameOnly"));
                
             //  Map<String, Object> text =  exchange.getIn().getHeaders();
               
 			    }
 			})
         .log("FT to file:${in.header.PGPPATH} DONE Sucessfully")
       .toD("file:${in.header.PGPPATH}");
        // .log("End of Processing")
    
        
    }
     
    
	/*
	 * public static class FW { public void execute(String str) {
	 * System.out.println("HelloWorld#execute: " + str); }
	 * 
	 * public void watch(String str) { System.out.println("H2H_FW: " + str);
	 * System.out.println("End of Processing"); System.out.println(" =&&&&= ");
	 * 
	 * } }
	 * 
	 * @Bean(name = "fw")
	 * 
	 * public FW fW() { return new FW(); }
	 */

}
